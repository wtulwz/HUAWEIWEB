<template>
  <div id="app">
    <router-view />
  </div>
</template>

<style>
@import './assets/HUAWEI_CSS_js_img/css/public.css';
@import './assets/HUAWEI_CSS_js_img/css/main.css';
@import './assets/HUAWEI_CSS_js_img/css/index.css';
@import './assets/HUAWEI_CSS_js_img/css/iconfont.css';
</style>
