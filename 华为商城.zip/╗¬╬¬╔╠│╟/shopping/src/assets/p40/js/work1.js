function real(){
    let homeBanner = document.getElementsByClassName('home-banner')[0].getElementsByClassName('layout');
    let array = [
        'https://res0.vmallres.com/shopdc/pic/dfccd45c-88e8-481d-90da-d7bae408eae4.jpg',
        'https://res4.vmallres.com/shopdc/pic/1ac1d0d6-29f3-4516-a693-698b4ad0ccb1.jpg',
        'https://res0.vmallres.com/shopdc/pic/4a5af99a-902e-4957-b237-7596670b7a9f.jpg',
    ];
    let icon = document.getElementsByClassName("icon")[0].getElementsByTagName("li");
    var index = 0;
    var start = null;
    function lunbo() {
        start = setInterval(() => {
            homeBanner[0].style.backgroundImage = "url(" + array[index] + ")";
            for (var i = 0; i < icon.length; i++) {
                icon[i].style.backgroundColor = "";
                icon[i].style.backgroundImage = "url(http://res2.vmallres.com/shopdc/pic/fe89b2e4-ca1d-42ae-b6ac-a7f54e5d6a4b.png)";
            }
            icon[index].style.backgroundColor = "white";
            icon[i].style.backgroundImage = "url(http://res2.vmallres.com/shopdc/pic/8547e797-492c-4cd7-9c94-e262217e9278.png)";
            index++;
            if (index == array.length) {
                index = 0;
            }
        }, 1000);
       /* start = window.setInterval(function () {
            
        }, 1000)*/
    }
    lunbo();
    // console.log(icon)
    for (let i = 0; i < array.length; i++) {
        icon[i].onmouseover = function () {
            index = i;
            homeBanner[0].style.backgroundImage = "url(" + array[i] + ")";
            for (var i = 0; i < icon.length; i++) {
                icon[i].style.backgroundColor = "";
                icon[i].style.backgroundImage = "url(http://res2.vmallres.com/shopdc/pic/fe89b2e4-ca1d-42ae-b6ac-a7f54e5d6a4b.png)";
            }
            icon[index].style.backgroundColor = "white";
            icon[i].style.backgroundImage = "url(http://res2.vmallres.com/shopdc/pic/8547e797-492c-4cd7-9c94-e262217e9278.png)";
        }
    }
    homeBanner[0].onmouseout = function () {
        window.clearInterval(start)
        lunbo();
    }
    homeBanner[0].onmouseover = function () {
        window.clearInterval(start)
    }
}

export  default real