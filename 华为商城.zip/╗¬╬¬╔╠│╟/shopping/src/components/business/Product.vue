<template>
  <div>
    <div class="hot_div">
      <div class="hot_top"><h2>热销新品</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in hot" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>精品手机</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in phone" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>平板电脑</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in pingban" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>智能穿戴 路由 盒子</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in router" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>热销配件</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in peijian" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>笔记本电脑</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in pc" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>商用笔记本电脑</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in pc2" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div class="hot_div">
      <div class="hot_top"><h2>智慧屏</h2></div>
      <div class="hot_bottom">
        <ul>
          <li v-for="(item, index) in ping" :key="index">
            <div class="hot_item">
              <img :src="item.img" />
              <p>{{ item.title }}</p>
              <div class="bottom_btn">
                <span>注册会员</span>
                <span style="border:none;color:red">立即购买 &gt;</span>
              </div>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      hot: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/28560666985f5ea455497405.png',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/3317151ddcf736de82edfbf1.png',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/1de83d49db1993a1d9e64e0c.png',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/20776468c8f5342e30f28f80.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/9d7bb3ca4a6d790102c29136.jpg',
          title: 'HUAWEI Mate 30 Pro 5G',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/dfb97cace577910f8a7b9a55.JPG',
          title: '荣耀30S',
          text1: '',
          text2: ''
        }
      ],
      phone: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/fe8a34b300045b15c3b484e6.png',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/be48b87b9029582979470e65.jpg',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/99501b12a2164ec49e6c157f.jpg',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/9c72a9eccf1a48dc405709fa.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/252282515eb539f769996770.jpg',
          title: 'HUAWEI Mate 30 Pro 5G',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/d82bef13f97649bb26f379aa.jpg',
          title: '荣耀30S',
          text1: '',
          text2: ''
        }
      ],
      pingban: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/9c013eadc5c1cda8624d58cb.jpg',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/84dbca24092499fc6d510dbb.jpg',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/f3a2afcb35461ae0e8c221e6.jpg',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/64c00dbd8bd50350163e34a9.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/11c8b9ae1c04064a21fc05d3.jpg',
          title: 'HUAWEI Mate 30 Pro 5G',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/aafbdb34aba4f7c0aa5a090a.jpg',
          title: '荣耀30S',
          text1: '',
          text2: ''
        }
      ],
      router: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/d6144eea862e575206e1f7d1.png',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/05fc2f1a29b4085374978536.jpg',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/f6ee7d99cd5c353bec59df35.jpg',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/bfaa68b719cf41b2de103c00.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/eb0f302fc36fd3c689b7d6eb.jpg',
          title: 'HUAWEI Mate 30 Pro 5G',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/2476c559c58d5f2b0cbc9e91.jpg',
          title: '荣耀30S',
          text1: '',
          text2: ''
        }
      ],
      peijian: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/044e9bc46f41c115a51bfcbe.jpg',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/7466b73e2cb94d4303f494dd.jpg',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/6a95e1395c63b69155663bce.jpg',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/0f60286096c213feb8abf34e.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/f910ba6fa794ce916abca204.jpg',
          title: 'HUAWEI Mate 30 Pro 5G',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/017b9002a4a1c5abd9b596dd.jpg',
          title: '荣耀30S',
          text1: '',
          text2: ''
        }
      ],
      pc: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/8c8f5a254929db8af7de2dd3.jpg',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/59e06ce25ce5361407fdbda4.jpg',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/088185f85f909e719a5cf5a1.jpg',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/a9ba23832c93be9a342968d4.jpg',
          title: '荣耀30S',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/03ed897d85a097f1914991e6.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/a3bd967d61f665defb0cd6c1.jpg',
          title: 'HUAWEI Mate 30 Pro 5G',
          text1: '',
          text2: ''
        }
      ],
      pc2: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/f84e6314849bc703de730c85.png',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/775f2b0552e18a8d336b801b.png',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/0b75a06746dffafc1cc6c944.png',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        }
      ],
      ping: [
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/ab31012f8f10c98623e0b23f.jpg',
          title: 'HUAWEI P40 Pro+',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/2c0ddb418e0c323e2efdf6a2.jpg',
          title: 'HUAWEI P40 Pro',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/88bccf83d848f3362575f23b.jpg',
          title: 'HUAWEI P40',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/da1236d3301c8c14ec19075e.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        },
        {
          url: '',
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/846efa03549d683744381f9a.jpg',
          title: '荣耀X10',
          text1: '',
          text2: ''
        }
      ]
    }
  },
  methods: {}
}
</script>
<style scoped>
.hot_div {
  width: 1200px;
  margin: 0 auto;
  height: 315px;
}
.hot_top {
  width: 100%;
  height: 42px;
}
.hot_top h2 {
  font-size: 20px;
}
.hop_bottom {
  width: 100%;
  height: 273px;
}
.hop_bottom li {
  float: left;
}
.hot_item {
  width: 196px;
  height: 263px;

  padding: 0 2px 10px;
  z-index: 1;
  text-align: center;
  float: left;
}
.hot_item:hover {
  transition: all 0.2s linear 0s;
  box-shadow: 0 10px 15px rgba(0, 0, 0, 0.07);
  transform: translate3d(0, -3px, 0);
  z-index: 2;
}
.hot_item img {
  width: 190px;
  height: 186.2px;
  padding-bottom: 15px;
}
.hot_item p {
  min-height: 18px;
  font-size: 12px;
  font-weight: 700;
  color: #000;
}
.bottom_btn {
  width: 86%;
  border: 1px solid #000;
  border-radius: 20px;
  margin: 0 auto;
  display: -ms-flexbox;
  display: flex;
  -ms-flex-pack: center;
  justify-content: center;
  -ms-flex-align: center;
  align-items: center;
  padding: 3px 0;
}
.bottom_btn span {
  font-size: 14px;
  flex: 1;
  border-right: 1px solid #000;
  text-align: center;
  line-height: 18px;
  color: #000;
}
</style>
