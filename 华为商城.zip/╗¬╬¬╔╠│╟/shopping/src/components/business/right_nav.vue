<template>
  <div>
    <div class="right">
      <ul>
        <li v-for="(rightnav, index) in right" :key="index">
          <a href="#"
            ><div class="right_child">
              <i :class="rightnav.icons"></i><br />
              {{ rightnav.title }}
            </div>
            <div class="right_left" v-if="rightnav.show">
              <div style="width:80px;margin:auto ">
                <p>950805(转)8</p>
              </div>
            </div>
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      right: [
        {
          icons: 'el-icon-phone',

          title: '采购热线',
          show: true
        },
        {
          icons: 'el-icon-chat-dot-square',

          title: '在线客服'
        },
        {
          icons: 'el-icon-question',
          title: '帮助中心'
        }
      ],
      top: false
    }
  },
  methods: {}
}
</script>
<style scoped>
.right {
  float: right;
  width: 64px;
  height: 224.8px;
  position: fixed;
  bottom: 150px;
  right: 0px;
  z-index: 333;
  background: white;
  border-top-left-radius: 10px;
  border-bottom-left-radius: 10px;
}

.right_child {
  width: 48px;
  height: 52.6px;
  text-align: center;
  color: #666;
  font-size: 12px;
  margin-left: 8px;
  margin-top: 18px;

  border-bottom: 1px solid #666;
}
.right_child i {
  font-size: 30px;
  padding-bottom: 6px;
}
.right_child:hover {
  transition: opacity 0.3s;
  color: #ff6700;
}
.right_left {
  display: none;
  position: absolute;
  left: -170px;
  top: 20px;
  height: 30px;
  width: 160px;
  background-color: #000;
  line-height: 30px;
  border-radius: 5px;
  font-size: 12px;
}

.right_left p {
  color: #fff;
}

.right_child:hover + div {
  display: block;
}
</style>
