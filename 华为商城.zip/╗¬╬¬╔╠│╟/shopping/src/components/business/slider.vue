<template>
  <div>
    <div id="slider">
      <div class="slider_div" @mouseover="stop" @mouseleave="play">
        <ul class="container" :style="containerStyle">
          <li>
            <img
              :style="{ width: imgWidth + 'px' }"
              :src="sliders[sliders.length - 1].img"
              alt=""
            />
          </li>
          <li v-for="(item, index) in sliders" :key="index">
            <img :style="{ width: imgWidth + 'px' }" :src="item.img" alt="" />
          </li>
          <li>
            <img
              :style="{ width: imgWidth + 'px' }"
              :src="sliders[0].img"
              alt=""
            />
          </li>
        </ul>
        <ul class="direction">
          <li class="left" @click="move(1500, 1)">
            <i class="el-icon-arrow-left"></i>
          </li>
          <li class="right" @click="move(1500, -1)">
            <i class="el-icon-arrow-right"></i>
          </li>
        </ul>
        <ul class="daohang">
          <li
            v-for="(dot, i) in sliders"
            :key="i"
            :class="{ dotted: i === currentIndex - 1 }"
            @click="jump(i + 1)"
          ></li>
        </ul>
      </div>
    </div>
    <div class="left_div">
      <div class="user-info">您好，欢迎来到华为商城企业购</div>
      <div class="passport-sigup" style="">
        <a
          class="passport-sigup-login"
          href="https://www.vmall.com/account/login?"
        ></a>
        <a
          href="https://company.vmall.com/auth/company/add"
          class="passport-sigup-sign"
        ></a>
      </div>

      <div class="passport-icon">
        <h2>企业专属权益</h2>
        <ul class="row clearfix passport-icon-bottom">
          <li class="col-xs-4">专属优惠</li>
          <li class="col-xs-4">专属客服</li>
          <li class="col-xs-4">采购合同</li>
        </ul>
        <br />
        <ul class="row clearfix passport-icon-top">
          <li class="col-xs-4">专票开具</li>
          <li class="col-xs-4">超长待单</li>
          <li class="col-xs-4">快通道发货</li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'slider',
  props: {
    initialSpeed: {
      type: Number,
      default: 30
    },
    initialInterval: {
      type: Number,
      default: 3
    }
  },
  data() {
    return {
      sliders: [
        {
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/bb06643dc91bc015ba213a33.jpg'
        },
        {
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/76a89b82ce27122c28aa23d2.png'
        },
        {
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/8a3fafd904d1d5073576950a.jpg'
        },
        {
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/378d2aadcb85b99a680597d7.jpg'
        }
      ],
      imgWidth: 1500,
      currentIndex: 1,
      distance: -1500,
      transitionEnd: true,
      speed: this.initialSpeed
    }
  },
  computed: {
    containerStyle() {
      return {
        transform: `translate3d(${this.distance}px, 0, 0)`
      }
    },
    interval() {
      return this.initialInterval * 1000
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.play()
      window.onblur = function() {
        this.stop()
      }.bind(this)
      window.onfocus = function() {
        this.play()
      }.bind(this)
    },
    move(offset, direction, speed) {
      console.log(speed)
      if (!this.transitionEnd) return
      this.transitionEnd = false
      direction === -1
        ? (this.currentIndex += offset / 1500)
        : (this.currentIndex -= offset / 1500)
      if (this.currentIndex > 4) this.currentIndex = 1
      if (this.currentIndex < 1) this.currentIndex = 4

      const destination = this.distance + offset * direction
      this.animate(destination, direction)
    },
    animate(des, direc, speed) {
      if (this.temp) {
        window.clearInterval(this.temp)
        this.temp = null
      }
      this.temp = window.setInterval(() => {
        if (
          (direc === -1 && des < this.distance) ||
          (direc === 1 && des > this.distance)
        ) {
          this.distance += speed * direc
        } else {
          this.transitionEnd = true
          window.clearInterval(this.temp)
          this.distance = des
          if (des < -6000) this.distance = -1500
          if (des > -1500) this.distance = -6000
        }
      })
    },
    jump(index) {
      const direction = index - this.currentIndex >= 0 ? -1 : 1
      const offset = Math.abs(index - this.currentIndex) * 1500
      const jumpSpeed =
        Math.abs(index - this.currentIndex) === 0
          ? this.speed
          : Math.abs(index - this.currentIndex) * this.speed
      this.move(offset, direction, jumpSpeed)
    },
    play() {
      if (this.timer) {
        window.clearInterval(this.timer)
        this.timer = null
      }
      this.timer = window.setInterval(() => {
        this.move(1500, -1, this.speed)
      }, this.interval)
    },
    stop() {
      window.clearInterval(this.timer)
      this.timer = null
    }
  }
}
</script>
<style scoped>
#slider {
  text-align: center;
}
.slider_div {
  position: relative;
  width: 1500px;
  height: 450px;
  margin: 0 auto;
  overflow: hidden;
}
.slider_div:hover .left {
  top: 10px;
  display: block;
  animation: fadeInLeft 0.5s 0.1s ease both;
}
@keyframes fadeInLeft {
  0% {
    opacity: 0;
    transform: translateX(-20px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}
.slider_div:hover .right {
  top: 10px;
  display: block;
  animation: fadeInright 0.5s 0.1s ease both;
}
@keyframes fadeInright {
  0% {
    opacity: 0;
    transform: translateX(20px);
  }
  100% {
    opacity: 1;
    transform: translateX(0);
  }
}
.container {
  display: flex;
  position: absolute;
}
.left,
.right {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 50px;
  height: 100%;
  background-color: transparent;
  cursor: pointer;
  color: white;
  font-weight: bolder;
  font-size: 36px;
  display: none;
}

.left {
  left: 0%;
  padding-left: 12px;
  padding-top: 200px;
}
.right {
  right: 0%;
  padding-right: 12px;
  padding-top: 200px;
}

.daohang {
  position: absolute;
  margin-top: 400px;
  left: 50%;
  transform: translateX(-50%);
}
.daohang li {
  display: inline-block;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: white;
  cursor: pointer;
  margin-left: 12px;
}
.daohang .dotted {
  border-radius: 25px;
  background: rgb(201, 29, 29);
  width: 40px;
  transition: all 0.4s;
}
img {
  user-select: none;
  width: 1500px;
  height: 450px;
}
.left_div {
  position: absolute;
  top: 145px;
  left: 170px;
  width: 296px;
  height: 400px;
  border-radius: 8px;
  padding: 25px 15px;
  background-color: #fff;
  box-sizing: border-box;
}
.user-info {
  text-align: center;
  font-size: 14px;
}
.passport-sigup {
  display: -ms-flexbox;
  display: flex;
  -ms-flex-pack: center;
  justify-content: center;
  -ms-flex-align: center;
  align-items: center;
  margin: 20px 0;
}
.passport-sigup a {
  display: inline-block;
  max-width: 125px;
  width: 125px;
  height: 30px;
  margin-right: 10px;
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/btn1_click.png)
    no-repeat;
  background-size: 100% 100%;
}
.passport-sigup a:last-child {
  margin-right: 0;
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/btn2_click.png)
    no-repeat;
  background-size: 100% 100%;
}
.passport-icon h2 {
  font-size: 18px;
  font-weight: 700;
  color: #333;
  margin: 10px 0 15px;
  text-align: center;
}
.row {
  margin-right: -15px;
  margin-left: -15px;
  overflow: hidden;
}

.clearfix {
  *zoom: 1;
}
.clearfix:before,
.clearfix:after {
  content: ' ';
  display: table;
}

.passport-icon ul li:before {
  content: '';
  display: block;
  width: 48px;
  height: 48px;
  margin: 0 auto;
  margin-bottom: 9px;
}

.col-xs-4 {
  position: relative;
  min-height: 1px;
  padding-right: 15px;
  padding-left: 22px;
  width: 33.33333333%;
  box-sizing: border-box;
  float: left;
  font-size: 12px;
  font-weight: bold;
}
.passport-icon-bottom li:nth-child(1) {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_promita.png)
    top center no-repeat;
}
.passport-icon-bottom li:nth-child(2) {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_user.png)
    top center no-repeat;
}
.passport-icon-bottom li:nth-child(3) {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_invoice.png)
    top center no-repeat;
}
.passport-icon-top li:nth-child(1) {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_special.png)
    top center no-repeat;
}
.passport-icon-top li:nth-child(2) {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_timeorder.png)
    top center no-repeat;
}
.passport-icon-top li:nth-child(3) {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_fastcar.png)
    top center no-repeat;
}
</style>
