<template>
  <div>
    <div class="top">
      <ul class="clearfix">
        <li class="com-li" v-for="(item, index) in top_div" :key="index">
          {{ item.text }}
        </li>
      </ul>
    </div>
    <br />
    <div id="slider">
      <div class="slider_div" @mouseover="stop" @mouseleave="play">
        <ul class="container" :style="containerStyle">
          <li>
            <img
              :style="{ width: imgWidth + 'px' }"
              :src="sliders[sliders.length - 1].img"
              alt=""
            />
          </li>
          <li v-for="(item, index) in sliders" :key="index">
            <img :style="{ width: imgWidth + 'px' }" :src="item.img" alt="" />
          </li>
          <li>
            <img
              :style="{ width: imgWidth + 'px' }"
              :src="sliders[0].img"
              alt=""
            />
          </li>
        </ul>
        <ul class="direction">
          <li class="left" @click="move(1500, 1)">
            <img
              src="https://res.vmallres.com/o2oc/c20200728/images/echannel/icon/arrow-left.png"
            />
          </li>
          <li class="right" @click="move(1500, -1)">
            <img
              src="https://res.vmallres.com/o2oc/c20200728/images/echannel/icon/arrow-right.png"
            />
          </li>
        </ul>
        <ul class="daohang">
          <li
            v-for="(dot, i) in sliders"
            :key="i"
            :class="{ dotted: i === currentIndex - 1 }"
            @click="jump(i + 1)"
          ></li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'slider',
  props: {
    initialSpeed: {
      type: Number,
      default: 30
    },
    initialInterval: {
      type: Number,
      default: 3
    }
  },
  data() {
    return {
      sliders: [
        {
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0230/c12706a7c6e8d6476c3d2b6ae0042a82/original/5cb1e09f12648b582850c8e0.jpg'
        },
        {
          img:
            'https://res.vmallres.com/o2oc/o2oc/U0860/31a6b5568bbb9c350c1b296d9086acf0/original/775a79d2e22c27adcde90ca8.png'
        }
      ],
      imgWidth: 1500,
      currentIndex: 1,
      distance: -1500,
      transitionEnd: true,
      speed: this.initialSpeed,
      top_div: [
        { text: '登录商城', imgurl: '' },
        { text: '企业用户认证', imgurl: '' },
        { text: '填写意向单', imgurl: '' },
        { text: '专享客服', imgurl: '' },
        { text: '订单生成及支付', imgurl: '' },
        { text: '快通道发货', imgurl: '' }
      ]
    }
  },
  computed: {
    containerStyle() {
      return {
        transform: `translate3d(${this.distance}px, 0, 0)`
      }
    },
    interval() {
      return this.initialInterval * 1000
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.play()
      window.onblur = function() {
        this.stop()
      }.bind(this)
      window.onfocus = function() {
        this.play()
      }.bind(this)
    },
    move(offset, direction, speed) {
      console.log(speed)
      if (!this.transitionEnd) return
      this.transitionEnd = false
      direction === -1
        ? (this.currentIndex += offset / 1500)
        : (this.currentIndex -= offset / 1500)
      if (this.currentIndex > 2) this.currentIndex = 1
      if (this.currentIndex < 1) this.currentIndex = 2

      const destination = this.distance + offset * direction
      this.animate(destination, direction)
    },
    animate(des, direc, speed) {
      if (this.temp) {
        window.clearInterval(this.temp)
        this.temp = null
      }
      this.temp = window.setInterval(() => {
        if (
          (direc === -1 && des < this.distance) ||
          (direc === 1 && des > this.distance)
        ) {
          this.distance += speed * direc
        } else {
          this.transitionEnd = true
          window.clearInterval(this.temp)
          this.distance = des
          if (des < -3000) this.distance = -1500
          if (des > -1500) this.distance = -3000
        }
      })
    },
    jump(index) {
      const direction = index - this.currentIndex >= 0 ? -1 : 1
      const offset = Math.abs(index - this.currentIndex) * 1500
      const jumpSpeed =
        Math.abs(index - this.currentIndex) === 0
          ? this.speed
          : Math.abs(index - this.currentIndex) * this.speed
      this.move(offset, direction, jumpSpeed)
    },
    play() {
      if (this.timer) {
        window.clearInterval(this.timer)
        this.timer = null
      }
      this.timer = window.setInterval(() => {
        this.move(1500, -1, this.speed)
      }, this.interval)
    },
    stop() {
      window.clearInterval(this.timer)
      this.timer = null
    }
  }
}
</script>
<style scoped>
.top {
  border: none;
}
.top ul {
  margin: 30px auto 0;
  width: 1074px;
  height: 120px;
}

.top ul .com-li:nth-child(1) {
  margin-left: 0;
}
.top ul li {
  float: left;
  text-align: center;
  position: relative;
  width: 100px;
  margin-left: 90px;
  font-size: 14px;
  color: #222;
  font-weight: 700;
}
.com-li:before {
  content: '';
  display: block;
  width: 48px;
  height: 48px;
  margin: 0 auto;
  margin-bottom: 13px;
}
.com-li:nth-child(1):before {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_login.png)
    no-repeat;
  background-size: cover;
}
.com-li:nth-child(2):before {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_comident.png)
    no-repeat;
  background-size: cover;
}
.com-li:nth-child(3):before {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_wish.png)
    no-repeat;
  background-size: cover;
}
.com-li:nth-child(4):before {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_user.png)
    no-repeat;
  background-size: cover;
}
.com-li:nth-child(5):before {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_orderpay.png)
    no-repeat;
  background-size: cover;
}
.com-li:nth-child(6):before {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/icon_fastcar.png)
    no-repeat;
  background-size: cover;
}

.com-li:after {
  content: '';
  width: 45px;
  height: 36px;
  display: block;
  position: absolute;
  left: -63px;
  top: 12px;
  background-position: 0 -500px;
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/djt.png)
    no-repeat;
}
#slider {
  text-align: center;
}
.slider_div {
  border: 0.5px solid rgb(226, 217, 217);
  position: relative;
  width: 1200px;
  height: 125px;
  margin: 0 auto;
  overflow: hidden;
}
.container {
  display: flex;
  position: absolute;
}
.left,
.right {
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
  width: 50px;
  height: 50px;
  background-color: transparent;
  cursor: pointer;
}

.left {
  left: 3%;
  padding-left: 12px;
  padding-top: 10px;
}
.right {
  right: 3%;
  padding-right: 12px;
  padding-top: 10px;
}
.left img {
  width: 35px;
  height: 50px;
  margin-top: -6px;
}
.right img {
  width: 35px;
  height: 50px;
  margin-top: -6px;
}

.daohang {
  position: absolute;
  margin-top: 90px;
  left: 50%;
  transform: translateX(-50%);
}
.daohang li {
  display: inline-block;
  width: 12px;
  height: 12px;

  border-radius: 50%;
  background: gray;
  cursor: pointer;
  margin-left: 7px;
}
.daohang .dotted {
  background: rgb(255, 255, 255);
}
img {
  user-select: none;
  width: 1200px;
  height: 125px;
}
</style>
