<template>
  <div>
    <div class="header">
      <div class="header-top" style="background-color: #f9f9f9;">
        <div class="layout">
          <div class="left">
            <ul>
              <li
                v-for="(item, index) in shortcutLeftList"
                :key="index"
                style=" border: none;"
              >
                <a href="#">{{ item.title }}</a>
              </li>
            </ul>
          </div>
          <div class="right">
            <ul>
              <li>
                <a href="#">请登录</a>
                <a href="#">注册</a>
              </li>
              <li><a href="#">我的订单</a></li>

              <li>
                <a href="#" class="icon-minicart">
                  <span>购物车</span>
                </a>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="header-bottom">
        <div class="layout">
          <div class="left">
            <a href="https://www.vmall.com/index.html">
              <div class="logo2"></div
            ></a>

            <div class="naver">
              <ul class="clearfix">
                <li
                  v-for="(item, index) in botttom_text"
                  :key="index"
                  style=" border: none;"
                >
                  <a :href="item.url"
                    ><span>{{ item.text }}</span></a
                  >
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      isShow: true,
      shortcutLeftList: [
        {
          title: '首页'
        },
        {
          title: '华为官网'
        },
        {
          title: '荣耀官网'
        },
        {
          title: '花粉俱乐部'
        },
        {
          title: '帮助中心'
        }
      ],
      botttom_text: [
        { text: '华为专区', url: 'https://www.vmall.com/huawei' },
        { text: '荣耀专区', url: 'https://sale.vmall.com/honor.html' },
        {
          text: '智能家居',
          url: 'https://www.vmall.com/huawei/smarthome2020.html'
        },
        { text: '手机解决方案', url: 'https://sale.vmall.com/jfacompany.html' },
        {
          text: '电脑解决方案',
          url: 'https://sale.vmall.com/qcjfacompany.html'
        },
        { text: '定制服务', url: 'https://sale.vmall.com/company-4.html' }
      ]
    }
  },
  methods: {}
}
</script>
<style scoped>
.logo2 {
  background: url(https://res.vmallres.com/o2oc/c20200728/images/index/com-logo.png);
  width: 296px;
  height: 70px;
  background-size: 296px 70px;
  background-repeat: no-repeat;
  margin-right: 34px;
  margin-top: -15px;
  float: left;
}
.header-top .layout .left a:hover {
  color: red;
}
.header-top .layout .right a:hover {
  color: red;
}
</style>
