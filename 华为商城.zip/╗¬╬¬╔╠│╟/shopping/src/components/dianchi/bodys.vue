<template>
  <div>
    <div class="top_div">
      <div class="top_image">
        <img
          src="https://res.vmallres.com/pimages//pages/ads/content/U2FBvc9tNYwbreh9gpzc.png"
        />
      </div>
    </div>
    <div class="bottom_div">
      <div class="middlediv">
        <div class="bg-gray">
          <div class="layout">
            <div class="hr-12"></div>
            <div class="service-shopping">
              <div class="h clearfix">
                <span class="title">购买电池更换服务</span>
                <ul class="service-shopping-tab clearfix">
                  <li class="current" id="tabID1">
                    <a href="javascript:;"><em>1</em>查询可购买电池更换服务</a>
                  </li>
                  <li id="tabID2">
                    <a href="javascript:;"> <em>2</em>购买电池更换服务</a>
                  </li>
                </ul>
              </div>
              <div class="b">
                <table class="form-input">
                  <tbody>
                    <tr>
                      <td class="form-input-name">
                        <span>*</span>
                        <label>手机SN号：</label>
                      </td>
                      <td>
                        <input
                          id="iMei"
                          name="iMei"
                          maxlength="20"
                          class="form-input-text"
                          type="text"
                          value=""
                          placeholder="输入8-20位SN号"
                          @blur="handleBlur"
                          :class="{ active: isActive }"
                        />
                      </td>
                    </tr>
                    <tr>
                      <td class="form-input-name">
                        <span>*</span><label>验证码：</label>
                      </td>
                      <td>
                        <div class="code-btn ">
                          <p class="clearfix">
                            <input
                              id="validateCode"
                              name="validateCode"
                              maxlength="4"
                              class="form-input-text"
                              type="text"
                              placeholder="输入右侧验证码"
                              @blur="handleBlur"
                              :class="{ active: isActive }"
                            />
                            <img
                              id="randomCodeImg"
                              src="https://www.vmall.com/order/batteryRandomCode?_t=1594889376097"
                            />
                            <a href="javascript:;">换一张</a>
                            <!--  @click="changeRandomCode" -->
                          </p>
                          <div
                            id="validateCode-message"
                            class="report-errors"
                          ></div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td></td>
                      <td>
                        <a id="nextStep" href="javascript:;" class="button-4"
                          >下一步</a
                        >
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="service-shopping-explain">
                <div class="clearfix1">
                  <div class="title">温馨提示：</div>
                  <ul>
                    <li>1、手机拨号键输入*#06#可查看相应SN号</li>
                    <li>2、产品包装盒或手机背贴上有相应的SN号</li>
                    <li>
                      3、打开手机设置-&gt;系统-&gt;关于手机-&gt;状态消息，可查看相应SN号（序列号）
                    </li>
                  </ul>
                </div>
                <div class="clearfix2">
                  <div class="title">购买说明：</div>
                  <ul>
                    <li>
                      1、一口价换电池服务仅限指定机型购买，购买后有效期30天，点击查看
                      <a
                        href="https://www.vmall.com/help/cfw002.html"
                        target="_blank"
                      >
                        可购买机型</a
                      >；
                    </li>
                    <li>
                      2、如您购买该商品后未使用，系统将在有效期（30天）过后3个工作日内进行审核，
                      <br />对未使用的订单进行自动退款，并于1-7个工作日退至原支付账号；
                    </li>
                    <li>
                      3、该商品不支持有效期内随时退换，如未使用，到期系统自动退款，给您造成的不便，敬请谅解；
                    </li>
                    <li>
                      4、请在购买前仔细阅读服务商品
                      <a
                        href="https://www.vmall.com/help/dcfw001.html"
                        target="_blank"
                        >《详情》</a
                      >
                      ，您的付费购买行为将被视为您了解并同意详情所述内容；
                    </li>
                    <li>
                      5、该服务产品购买后需要在华为授权服务中心实现电池更换，您可通过直接到店、
                      <a
                        href="https://consumer.huawei.com/cn/support/reservation/"
                        target="_blank"
                        >预约</a
                      >
                      、<a
                        href="https://consumer.huawei.com/cn/support/express-repair/"
                        target="_blank"
                        >寄修</a
                      >
                      等形式接受服务；
                    </li>
                    <li>
                      6、如在购买过程中遇到问题，请拨打华为客户服务热线950805咨询
                      。
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped>
.top_div {
  width: 100%;
  height: 455px;
  margin-top: 45px;
}
.top_div .top_image {
  width: 1397px;
  height: 450px;
  margin: 0 auto;
}
.top_div .top_image img {
  width: 100%;
  height: 100%;
}
.bottom_div {
  width: 100%;
  height: 712px;
  background: #f5f5f5;
}
.middlediv {
  width: 1200px;
  height: 712px;
  background: white;
  margin: 0 auto;
}

.hr-12 {
  width: 1200px;
  height: 12px;
  margin: 0px auto;
  border-color: #f5f5f5;
}
.service-shopping {
  background-color: #ffffff;
  width: 940px;
  height: 620px;
  margin: 0 auto;
  margin-bottom: 10px;
  position: relative;
  padding: 43px 130px 0;
}
.service-shopping .h {
  border-bottom: 1px solid #dedede;
  padding-bottom: 10px;
}
.service-shopping .h .title {
  font-size: 20px;
  line-height: 34px;
  position: relative;
  top: 2px;
  float: left;
}
.h .clearfix {
  height: 45px;
  background-color: #fff;
  position: relative;
}
.service-shopping .h .service-shopping-tab {
  float: right;
  width: 385px;
  overflow: hidden;
}
.service-shopping .h .service-shopping-tab li:first-child {
  z-index: 3;
  border-radius: 2px 0 0 2px;
}
.service-shopping .h .service-shopping-tab li:first-child a {
  border-radius: 2px 0 0 2px;
}
.service-shopping .h .service-shopping-tab li.current a {
  background: #ca141d;
  color: #fff;
}
.service-shopping .h .service-shopping-tab li a {
  background: #fafafa;
  display: block;
  width: 185px;
  height: 34px;
  line-height: 34px;
  text-align: center;
  font-size: 14px;
  border-radius: 2px;
  position: relative;
  cursor: default;
}
.service-shopping .h .service-shopping-tab li.current a:before {
  border-left: 11px solid #ca141d;
}
.service-shopping .h .service-shopping-tab li a:before {
  content: '';
  width: 0;
  height: 0;
  border-top: 17px solid transparent;
  border-bottom: 17px solid transparent;
  border-left: 11px solid #fafafa;
  position: absolute;
  top: 0;
  right: -10px;
}
.service-shopping .h .service-shopping-tab li.current em {
  background: #fff;
  color: #ca141d;
}
.service-shopping .h .service-shopping-tab li:last-child {
  width: 196px;
  border-radius: 0 2px 2px 0;
}
.service-shopping .h .service-shopping-tab li {
  background: #fff;
  width: 189px;
  height: 34px;
  position: relative;
  float: left;
}
.service-shopping .h .service-shopping-tab li:before {
  content: '';
  width: 0;
  height: 0;
  border-top: 17px solid transparent;
  border-bottom: 17px solid transparent;
  border-left: 11px solid #fff;
  position: absolute;
  top: 0;
  right: -11px;
}
.service-shopping .h .service-shopping-tab li:last-child a {
  width: 196px;
  border-radius: 0 2px 2px 0;
}
.service-shopping .h .service-shopping-tab li a {
  background: #fafafa;
  display: block;
  width: 185px;
  height: 34px;
  line-height: 34px;
  text-align: center;
  font-size: 14px;
  border-radius: 2px;
  position: relative;
  cursor: default;
}
.service-shopping .h .service-shopping-tab li em {
  background: #666;
  height: 14px;
  line-height: 14px;
  color: #fff;
  padding: 0 3px;
  border-radius: 2px;
  margin-right: 9px;
  font-size: 12px;
}
.b {
  width: 800px;
  height: 187px;
}
.service-shopping .form-input .form-input-name {
  line-height: 35px;
  font-size: 15px;
}

.form-input .form-input-name {
  color: #3a3a3a;
  text-align: left;
  padding-left: 30px;
  padding-top: 35px;
  line-height: 35px;
}
.form-input td {
  font-size: 14px;
}

.form-input .form-input-name span {
  margin-right: 10px;
  position: relative;
  top: 2px;
  color: #ca141d;
}
.service-shopping input.form-input-text {
  width: 330px;
  height: 33px;
  line-height: 33px;
  text-indent: 14px;
  border: 1px solid #d6d6d6;
  margin-top: 25px;
  margin-left: 20px;
  margin-right: 20px;
  float: left;
  transition: border-color 0.3s ease;
}
.service-shopping .code-btn input.form-input-text {
  width: 130px;
}
.service-shopping .code-btn img {
  width: 100px;
  height: 30px;
  float: left;
  margin-left: 10px;
  margin-top: 30px;
  margin-right: 10px;
}

.service-shopping .code-btn a {
  float: left;
  margin-top: 40px;
  text-decoration: underline;
  color: #717171;
}
.button-4 {
  width: 170px;
  line-height: 44px;
  border: 1px solid #ddd;
  text-align: center;
  font-size: 18px;
  background: #fff;
  border-radius: 2px;
  display: inline-block;
  margin-left: 20px;
  margin-top: 25px;
}
.service-shopping-explain {
  color: #888;
  font-size: 14px;
  padding-bottom: 80px;
  position: relative;
  left: -24px;
}
.service-shopping-explain .clearfix1 {
  padding-top: 52px;
}
.service-shopping-explain .clearfix2 {
  padding-top: 28px;
}
.service-shopping-explain .title {
  display: inline-block;
  width: 126px;
  text-align: right;
  vertical-align: top;
}
.service-shopping-explain ul {
  display: inline-block;
  vertical-align: top;
}
.service-shopping-explain a {
  color: #ca141d;
  text-decoration: underline;
}
</style>
