<template>
  <div>
    <div class="footer">
      <div class="cj_pannel">
        <div class="layout">
          <div class="all_pannel">
            <div
              :class="[item.isItem ? 'item' : 'selectBox', item.clsName]"
              v-for="(item, index) in pannelList"
              :key="index"
            >
              <img :src="item.ImgSrc" alt="" />
            </div>
          </div>
          <div class="vip_number">
            <div class="vip-Flip-content">
              <div class="prize-content">
                <p v-for="(item, index) in spanList" :key="index">
                  <span style="white-space: normal;">{{ item.title }}</span
                  ><br />
                </p>
              </div>
              <p class="v-rule">更多详情<span>&gt;</span></p>
            </div>
            <div class="v-desc">
              <marquee
                style="height:145px;"
                onmouseout="this.start();"
                onmouseover="this.stop();"
                scrollamount="2"
                behavior="scroll"
                direction="up"
              >
                <ul id="prizeList">
                  <li
                    class="clearfix"
                    v-for="(item, index) in marList"
                    :key="index"
                  >
                    <div class="text-left">{{ item.text_f }}</div>
                    <div class="text-right">{{ item.text_r }}</div>
                  </li>
                </ul>
              </marquee>
            </div>
          </div>
        </div>
      </div>
      <div class="back-top">
        <div class="layout">
          <a
            :href="itemA.href"
            v-for="(itemA, index) in backTopList"
            :key="index"
            >{{ itemA.text }}</a
          >
        </div>
      </div>
      <div class="bottom-pic"></div>
      <div class="more"><a href=""> </a></div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Footer',
  data() {
    return {
      backTopList: [
        {
          href: 'javascript:void(0)',
          text: ''
        },
        {
          href: '#',
          text: ''
        }
      ],
      pannelList: [
        {
          isItem: true,
          clsName: 'i1',
          ImgSrc:
            'https://res9.vmallres.com/shopdc/pic/8bf32c85-4d7d-4036-8d88-b0e2bd8767ca.png'
        },
        {
          isItem: true,
          clsName: 'i2',
          ImgSrc:
            'https://res5.vmallres.com/shopdc/pic/a38461b2-8317-4a66-877a-ee3d1ed8ea27.png'
        },
        {
          isItem: true,
          clsName: 'i3',
          ImgSrc:
            'https://res1.vmallres.com/shopdc/pic/1a70c905-20c6-46d5-a7c3-2c14a36a0c68.png'
        },
        {
          isItem: true,
          clsName: 'i4',
          ImgSrc:
            'https://res8.vmallres.com/shopdc/pic/98b26dbb-a506-41ca-afeb-0d78312839b2.png'
        },
        {
          isItem: true,
          clsName: 'i5',
          ImgSrc:
            'https://res4.vmallres.com/shopdc/pic/ef1e4f17-3fba-45fc-9fb5-6f65c7dbfe01.png'
        },
        {
          isItem: true,
          clsName: 'i6',
          ImgSrc:
            'https://res5.vmallres.com/shopdc/pic/d2837dac-2c7e-40db-ac19-592fb53c858f.png'
        },
        {
          isItem: true,
          clsName: 'i7',
          ImgSrc:
            'https://res1.vmallres.com/shopdc/pic/bbb4b32f-89f5-452b-bcb3-02b52cc2aadd.png'
        },
        {
          isItem: true,
          clsName: 'i8',
          ImgSrc:
            'https://res8.vmallres.com/shopdc/pic/0d6e798a-4b47-4146-b3a1-bd95d59fa793.png'
        },
        {
          isItem: false,
          clsName: null,
          ImgSrc:
            'https://res0.vmallres.com/shopdc/pic/7848e6d2-8420-410e-893d-fbd3b9ac1e78.png'
        }
      ],
      spanList: [
        {
          title: '1、活动时间：2020年8月1日00:00-8月31日23:59'
        },
        {
          title:
            '2、活动规则：活动期间用户登陆华为商城帐号，进入活动页面，点击参与抽奖，同一帐号每天有3次免费抽奖机会。'
        },
        {
          title:
            '抽奖机会当天有效不累计。分享1次可获得1次额外抽奖机会，商城所有活动页面翻牌抽奖奖品及次数共享。'
        },
        {
          title: '3、奖品设置：'
        },
        {
          title: '一等奖（1名）： 荣耀手表2   1个'
        },
        {
          title: '二等奖（5名）：HUAWEI FreeLace无线耳机 1个'
        },
        {
          title: '三等奖（20名）：海雀智能摄像头 超清云台版 1个'
        },
        {
          title: '四等奖（20名）：荣耀路由X1 增强版 1个'
        },
        {
          title: '幸运奖（200,000名）：华为品牌优惠券 1张'
        },
        {
          title: '幸运奖（200,000名）：荣耀品牌优惠券 1张'
        },
        {
          title: '幸运奖（200,000名）：生态产品优惠券 1张'
        }
      ],
      marList: [
        {
          text_f: '150****7085',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '189****3228',
          text_r: '抽中 华为品牌  10元优惠券'
        },
        {
          text_f: '185****1000',
          text_r: '抽中 荣耀品牌  100元优惠券'
        },
        {
          text_f: '138****9537',
          text_r: '抽中 荣耀品牌  100元优惠券'
        },
        {
          text_f: '132****8807',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '189****6833',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '159****1483',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '177****1248',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '155****6399',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '139****8765',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '136****1412',
          text_r: '抽中 荣耀品牌  10元优惠券'
        },
        {
          text_f: '136****9528',
          text_r: '抽中 荣耀品牌  100元优惠券'
        },
        {
          text_f: '185****9528',
          text_r: '抽中 华为品牌  10元优惠券'
        },
        {
          text_f: '159****9528',
          text_r: '抽中 荣耀品牌  100元优惠券'
        },
        {
          text_f: '180****8007',
          text_r: '抽中 华为品牌  10元优惠券'
        }
      ]
    }
  }
}
</script>
<style scoped>
.footer {
  width: 100%;
  max-width: 100%;
  margin: 0 auto;
}
.footer .cj_pannel {
  height: 549px;
  background-image: url(https://res5.vmallres.com/shopdc/pic/9a97d65e-aae8-4a74-b15c-8689769f0ad4.png);
  background-repeat: no-repeat;
  background-position-x: 50%;
  margin-bottom: 41px;
}
.footer .cj_pannel .all_pannel {
  width: 715.5px;
  float: left;
  height: 508px;
  font-size: 0;
  position: relative;
  margin-left: 46px;
  margin-top: 41px;
  border-radius: 18px;
}
.footer .cj_pannel .all_pannel .item {
  width: 220px;
  height: 160px;
  position: absolute;
  left: 50%;
  top: 50%;
  margin-left: -110px;
  margin-top: -80px;
  z-index: 1;
}
.footer .cj_pannel .all_pannel img {
  width: 220px;
  height: 160px;
  background-position: center;
  background-repeat: no-repeat;
  background-size: 100%;
}
.footer .cj_pannel .all_pannel div:nth-of-type(9) img {
  width: 144px;
  height: 144px;
}
.footer .cj_pannel .all_pannel .i1 {
  transform: translate3d(-233.026px, -174px, 0px);
}
.footer .cj_pannel .all_pannel .i2 {
  transform: translate3d(0px, -174px, 0px);
}
.footer .cj_pannel .all_pannel .i3 {
  transform: translate3d(233.026px, -174px, 0px);
}
.footer .cj_pannel .all_pannel .i4 {
  transform: translate3d(-233.026px, 0px, 0px);
}
.footer .cj_pannel .all_pannel .i5 {
  transform: translate3d(233.026px, 0px, 0px);
}
.footer .cj_pannel .all_pannel .i6 {
  transform: translate3d(-233.026px, 174px, 0px);
}
.footer .cj_pannel .all_pannel .i7 {
  transform: translate3d(0px, 174px, 0px);
}
.footer .cj_pannel .all_pannel .i8 {
  transform: translate3d(233.026px, 174px, 0px);
}
.footer .cj_pannel .all_pannel .selectBox {
  position: absolute;
  left: 40%;
  top: 36%;
  width: 144px;
  height: 144px;
}
.footer .cj_pannel .vip_number {
  width: 430px;
  height: 420px;
  float: right;
  position: relative;
  top: 129px;
}
.footer .cj_pannel .vip_number .vip-Flip-content {
  position: absolute;
  left: 71px;
  right: 40px;
  width: 267px;
  height: 140px;
  font-family: MicrosoftYaHei;
  font-size: 14px;
  color: #908c8a;
  letter-spacing: 0;
  text-align: justify;
  line-height: 1.7;
  margin-top: -550px;
}
.footer .cj_pannel .vip_number .vip-Flip-content .prize-content {
  height: 140px;
  display: -webkit-box;
  -webkit-line-clamp: 6;
  -webkit-box-orient: vertical;
  word-break: break-word;
  overflow: hidden;
  text-overflow: ellipsis;
}
.footer .cj_pannel .vip_number .vip-Flip-content .v-rule {
  font-family: SourceHanSansCN-Normal;
  font-size: 14px;
  color: #ea380f;
  cursor: pointer;
}
.footer .cj_pannel .vip_number .v-desc {
  position: absolute;
  left: 101px;
  right: 20px;
  width: 269px;
  margin-top: -320px;
}
.footer .cj_pannel .vip_number .v-desc > ul {
  font-family: MicrosoftYaHei;
  font-size: 14px;
  line-height: 21px;
  color: #3a3a3a;
  word-break: break-word;
}
.footer .back-top {
  height: 90px;
  background-repeat: no-repeat;
  background-position-x: 50%;
  background-image: url(https://res2.vmallres.com/shopdc/pic/f37e00fe-d613-4559-990a-15cff80d394b.png);
}
.footer .back-top .layout {
  height: 90px;
  position: relative;
}
.footer .back-top .layout a {
  display: inline-block;
  width: 200px;
  height: 50px;
  margin: 0;
  padding-left: 50px;
  position: absolute;
  top: 18px;
  border-radius: 75px;
  font-size: 20px;
  font-weight: 500;
  line-height: 60px;
}

.footer .back-top .layout a:nth-of-type(1) {
  left: 19% !important;
}
.footer .back-top .layout a:nth-of-type(2) {
  right: 19% !important;
}
.footer .bottom-pic {
  height: 459px;
  background-repeat: no-repeat;
  background-position-x: 50%;
  background-image: url(https://res7.vmallres.com/shopdc/pic/419d5083-ab69-4c10-83c4-44717e93cd20.png);
  width: 100%;
}
.footer .more {
  top: 9150px;
  height: 30px;
  width: 900px;
  position: absolute;
  /* top: 3px; */
  z-index: 10;
}

.footer .more:hover {
  cursor: pointer;
}
</style>
