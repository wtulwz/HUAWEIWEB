<template>
  <div>
    <div class="header-banner">
      <div class="home-img">
        <img
          src="https://res6.vmallres.com/shopdc/pic/aeb44560-a4c2-4f72-a22b-d119cfa7a81a.jpg"
          alt=""
        />
      </div>
    </div>
    <div class="slide" v-on:mouseover="stop()" v-on:mouseout="move()">
      <el-carousel height="450px" :interval="5000" arrow="never">
        <el-carousel-item v-for="(item, index) in mainBannerList" :key="index">
          <img :src="item" alt="" />
        </el-carousel-item>
      </el-carousel>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Header',
  data() {
    return {
      LiIcon: [
        {
          title: '1'
        },
        {
          title: '2'
        },
        {
          title: '3'
        },
        {
          title: '4'
        },
        {
          title: '5'
        },
        {
          title: '6'
        },
        {
          title: '7'
        }
      ],
      mainBannerList: [
        'https://res2.vmallres.com/shopdc/pic/4773f099-ecf9-407e-9183-6f2b29a2e543.jpg',
        'https://res5.vmallres.com/shopdc/pic/64212f61-d540-4aa3-9166-2e7c9354e34a.jpg',
        'https://res1.vmallres.com/shopdc/pic/9af1c9a9-6fda-4f58-9c46-f03aaa9f0d01.jpg',
        'https://res8.vmallres.com/shopdc/pic/49541a4e-61b8-468b-8d5f-28de5ff2ac9f.jpg',
        'https://res0.vmallres.com/shopdc/pic/3adcb03d-7e99-496c-8ef0-70e2b9e01afa.jpg',
        'https://res5.vmallres.com/shopdc/pic/7de16fc7-0e09-4510-9d8e-e85de3c49e29.jpg',
        'https://res2.vmallres.com/shopdc/pic/d21d23ed-6f26-4aa2-91ff-94918d524bef.jpg'
      ]
    }
  },
  methods: {}
}
</script>
<style scoped>
.header-banner {
  height: 60px;
  position: relative;
  text-align: center;
  max-width: 100%;
}

.header-banner .home-img {
  width: 100%;
  max-width: 100%;
  height: 60px;
  margin: 0 auto;
}
.header-banner img {
  max-width: 100%;
  height: 60px;
  background-size: 200%;
}

/* 轮播 */
.slide {
  width: 100%;
  max-width: 100%;
  margin: 0 auto;
  height: 450px;
  position: relative;
}
.slide img {
  width: 100%;
  height: 550px;
  background-position: center;
  background-repeat: no-repeat;
  vertical-align: top;
  transition: all 1.5s linear;
  /* border: 1px solid red; */
}
.slide ul {
  position: absolute;
  height: 10px;
  /* width: 100px; */
  bottom: 10px;
  left: 45% !important;
  /* border: 1px solid red; */
}
.slide ul li {
  width: 14px;
  height: 14px;
  float: left;
  margin-left: 6px;
  /* background: url(https://res2.vmallres.com/shopdc/pic/fe89b2e4-ca1d-42ae-b6ac-a7f54e5d6a4b.png) no-repeat; */
}
.slide ul li:hover {
  cursor: pointer;
}
</style>
