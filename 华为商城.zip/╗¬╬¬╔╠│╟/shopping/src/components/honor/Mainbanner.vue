<template>
  <div class="mainbanner">
    <div class="layout">
      <div class="contentCjxp"></div>
      <div class="contentCjxp1"></div>
      <div class="contentCjxp2"></div>
      <div class="contentCjxp3"></div>
      <div class="contentCjxp4" id="5g"></div>
      <div class="grid-12">
        <ul>
          <li v-for="(item, index) in goodsList1" :key="index">
            <a href="javascript:void(0)">
              <p class="pic">
                <img :src="item.Imgsrc" alt="" />
              </p>
              <p class="title">{{ item.title }}</p>
              <p class="desc">{{ item.desc }}</p>
              <p class="sale">{{ item.sale }}</p>
              <div class="price-wrp">
                <p class="price" style="color:#FFFFFF;">
                  <span class="price-currency">{{ item.priceCurrency }}</span>
                  <span class="price-amount">{{ item.priceAmount }}</span>
                  <span class="price-from">{{ item.priceFrom }}</span>
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="contentCjxp5" id="phone"></div>
      <div class="grid-8">
        <ul>
          <li v-for="(item, index) in goodsList2" :key="index">
            <a href="javascript:void(0)">
              <p class="pic">
                <img :src="item.Imgsrc" alt="" />
              </p>
              <p class="title">{{ item.title }}</p>
              <p class="desc">{{ item.desc }}</p>
              <p class="sale">{{ item.sale }}</p>
              <div class="price-wrp">
                <p class="price" style="color:#FFFFFF;">
                  <span class="price-currency">{{ item.priceCurrency }}</span>
                  <span class="price-amount">{{ item.priceAmount }}</span>
                  <span class="price-from">{{ item.priceFrom }}</span>
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="contentCjxp6" id="baokuan"></div>
      <div class="grid-8">
        <ul>
          <li v-for="(item, index) in goodsList3" :key="index">
            <a href="javascript:void(0)">
              <p class="pic">
                <img :src="item.Imgsrc" alt="" />
              </p>
              <p class="title">{{ item.title }}</p>
              <p class="desc">{{ item.desc }}</p>
              <p class="sale">{{ item.sale }}</p>
              <div class="price-wrp">
                <p class="price" style="color:#FFFFFF;">
                  <span class="price-currency">{{ item.priceCurrency }}</span>
                  <span class="price-amount">{{ item.priceAmount }}</span>
                  <span class="price-from">{{ item.priceFrom }}</span>
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="contentCjxp7" id="chaoliu"></div>
      <div class="grid-12">
        <ul>
          <li v-for="(item, index) in goodsList4" :key="index">
            <a href="javascript:void(0)">
              <p class="pic">
                <img :src="item.Imgsrc" alt="" />
              </p>
              <p class="title">{{ item.title }}</p>
              <p class="desc">{{ item.desc }}</p>
              <p class="sale">{{ item.sale }}</p>
              <div class="price-wrp">
                <p class="price" style="color:#FFFFFF;">
                  <span class="price-currency">{{ item.priceCurrency }}</span>
                  <span class="price-amount">{{ item.priceAmount }}</span>
                  <span class="price-from">{{ item.priceFrom }}</span>
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
      <div class="contentCjxp8"></div>
      <div class="contentCjxp9"></div>
      <div class="contentCjxp10"></div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Mainbanner',
  data() {
    return {
      logoList: {
        icon_1:
          'https://res2.vmallres.com/shopdc/pic/1aa10973-abd3-4565-8624-6d411041986a.jpg'
      },
      goodsList1: [
        {
          Imgsrc:
            'https://res9.vmallres.com/shopdc/pic/78a48bda-777e-406d-9b48-5ee7349f34ee.jpg',
          title: '荣耀X10',
          desc: '麒麟820 90Hz全速屏',
          sale: '享12期免息',
          priceCurrency: '¥',
          priceAmount: '1899',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res1.vmallres.com/shopdc/pic/a5054a9d-3e44-48ef-b1b0-8565d340222f.png',
          title: '荣耀Play4 Pro',
          desc: '麒麟990|40W超级快充',
          sale: '最高优惠410',
          priceCurrency: '¥',
          priceAmount: '2499',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/shopdc/pic/723c8a82-e8c9-4858-b7b4-ef2ae873a939.jpg',
          title: '荣耀30S',
          desc: 'title="麒麟820 5G芯片 | 3倍光学变焦"',
          sale: '限量送移动电源',
          priceCurrency: '¥',
          priceAmount: '2099',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/shopdc/pic/1aa45dc2-4cf1-4faf-a374-0c804d2d99b2.jpg',
          title: '荣耀X10 Max',
          desc: '7.09英寸RGBW护眼阳光屏',
          sale: '12期免息',
          priceCurrency: '¥',
          priceAmount: '1899',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res8.vmallres.com/shopdc/pic/2e1b19a8-6c65-44e9-b6c8-bbe48ffa124d.jpg',
          title: '荣耀 MagicBook Pro 2020',
          desc: '全新7nm 锐龙标压强劲处理器',
          sale: '限时优惠200元',
          priceCurrency: '¥',
          priceAmount: '4499',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/shopdc/pic/ee1901cb-2529-4440-a8df-a0d642292656.jpg',
          title: '荣耀V30',
          desc: '麒麟990 | 突破性相机矩阵',
          sale: '最高优惠810',
          priceCurrency: '¥',
          priceAmount: '2499',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res6.vmallres.com/pimages//product/6972453166210/428_428_67DF9B4F421F8FDE6E1098A389E2CA7CD23F631E366B2AE1mp.png',
          title: '荣耀平板V6 5G',
          desc: '全球首款5G和Wifi6+平板',
          sale: '最高优惠150',
          priceCurrency: '¥',
          priceAmount: '3159',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/pimages//product/6901443401956/428_428_9A49CD2E2A487CA47DC30109246CD63A185CE6C743E762B7mp.png',
          title: '荣耀智慧屏X1系列 50英寸',
          desc: '4K超清全面屏',
          sale: '预订最高优惠300元',
          priceCurrency: '¥',
          priceAmount: '1999',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/shopdc/pic/fc4cd233-b7ff-4a68-8b13-60e67f6e7cfe.jpg',
          title: '荣耀手表',
          desc: '46mm 运动款碳石黑',
          sale: '限时预订799起',
          priceCurrency: '¥',
          priceAmount: '1099',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/shopdc/pic/62dd349b-3231-44af-95cd-051c39bd9f83.jpg',
          title: '荣耀 FlyPods 3',
          desc: '双重主动降噪 | 三麦克通话降噪',
          sale: '下单使用1000以内积分可双倍抵现',
          priceCurrency: '¥',
          priceAmount: '799',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/pimages//product/6901443407170/428_428_94C37897A70207E984618A91DFB43F500D0A40471D69CF54mp.png',
          title: '荣耀MagicBook 14 2020',
          desc: '微边全面屏 | AMD锐龙处理器',
          sale: '新品最高优惠200元',
          priceCurrency: '¥',
          priceAmount: '3799',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/pimages//product/6901443408948/428_428_BA79A98270532F130786EDB2E39FD6BC934D59F5DF9B5FDEmp.png',
          title: '荣耀MagicBook 15 2020',
          desc: '全新7nm 锐龙强劲处理器',
          sale: '新品最高优惠200元',
          priceCurrency: '¥',
          priceAmount: '3199',
          priceFrom: '起'
        }
      ],
      goodsList2: [
        {
          Imgsrc:
            'https://res3.vmallres.com/shopdc/pic/2da3eb42-af08-4660-8502-6b88b74a53a5.jpg',
          title: '荣耀  Play4T',
          desc: '大电池 | 6.39英寸大屏  | 人脸识别',
          sale: '最高优惠110元',
          priceCurrency: '¥',
          priceAmount: '999',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res3.vmallres.com/shopdc/pic/8d0f1bd8-3674-4dfa-9930-671c134900aa.jpg',
          title: '荣耀  Play4T  Pro',
          desc: '麒麟810芯片  OLED屏幕指纹',
          sale: '全系优惠110元',
          priceCurrency: '¥',
          priceAmount: '1399',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/shopdc/pic/97a23f29-2518-4625-8d14-37ede0cfbe74.jpg',
          title: '荣耀9X',
          desc: '麒麟810  |  4000mAh超强续航',
          sale: '最高优惠400元',
          priceCurrency: '¥',
          priceAmount: '1099',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res5.vmallres.com/shopdc/pic/fed329a5-a89b-40df-baea-4f962be27f04.png',
          title: '荣耀畅玩9A',
          desc: '三天一充 | 超长续航',
          sale: '10/12/14/16/20/22点限量赠AM115耳机（荣耀指定产品共享）',
          priceCurrency: '¥',
          priceAmount: '899',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res8.vmallres.com/shopdc/pic/6e477172-983c-41f5-a957-8d69730a97e5.jpg',
          title: '荣耀V30 PRO',
          desc: '双模5G | 麒麟990 5G SOC芯片',
          sale: '优惠500 部分送配件',
          priceCurrency: '¥',
          priceAmount: '3399',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res8.vmallres.com/shopdc/pic/6f2ca4ac-040c-444b-bb57-d4a5b3bc66eb.jpg',
          title: '荣耀Play3',
          desc: '6.39英寸魅眼全视屏',
          sale: '最高优惠310元',
          priceCurrency: '¥',
          priceAmount: '899',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res7.vmallres.com/shopdc/pic/e0e68cc3-670d-4613-bd04-dfc2b27a1287.jpg',
          title: '荣耀20 PRO',
          desc: '4800万全焦段AI四摄 | 麒麟980',
          sale: '限时直降600元',
          priceCurrency: '¥',
          priceAmount: '2099',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res1.vmallres.com/shopdc/pic/cca3f656-df94-4efb-982c-e7df86589661.png',
          title: '荣耀30青春版',
          desc: '高感光超清美拍',
          sale: '6期免息|享多重好礼',
          priceCurrency: '¥',
          priceAmount: '1699',
          priceFrom: '起'
        }
      ],
      goodsList3: [
        {
          Imgsrc:
            'https://res1.vmallres.com/shopdc/pic/bdb77bfa-2996-4c13-a70d-aba52f8fc325.jpg',
          title: '荣耀智慧屏系列',
          desc: '4K超清全面屏 | 鸿蒙系统',
          sale: '最高优惠1300元',
          priceCurrency: '¥',
          priceAmount: '2999',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res6.vmallres.com/pimages//product/6901443360079/428_428_1F4642A1AFA3153AF3BFCE0141C98724271C4FEA2786F268mp.png',
          title: '荣耀MagicBook 14',
          desc: '全面屏微边框轻薄机身',
          sale: '限时直降300元',
          priceCurrency: '¥',
          priceAmount: '3599',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/pimages//product/6901443330720/428_428_09F234E37A3F711772ACD5FD0155CB0905423FDA9D230BA8mp.png',
          title: '荣耀 MagicBook Pro',
          desc: '全新锐龙游戏本级处理器',
          sale: '100最高抵1300+赠耳机',
          priceCurrency: '¥',
          priceAmount: '4299',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res1.vmallres.com/pimages//product/6972453163493/428_428_967428BB4A8D3A5874702300F960A6F01AF0D250D3EA3EFDmp.png',
          title: '荣耀路由3',
          desc: 'Wifi6+智能分频',
          sale: '限时直降20元',
          priceCurrency: '¥',
          priceAmount: '209',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res5.vmallres.com/pimages//product/6901443404735/428_428_BD68FD05505866C768270304E443D6B3A0099C0A1AAAC99Bmp.png',
          title: '荣耀平板6',
          desc: '双重护眼认证',
          sale: '最高优惠500',
          priceCurrency: '¥',
          priceAmount: '1299',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/pimages//product/6901443270385/428_428_1545268730575mp.png',
          title: '荣耀FlyPods青春版',
          desc: '真无线耳机',
          sale: '下单使用500以内积分可双倍抵现',
          priceCurrency: '¥',
          priceAmount: '399',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res7.vmallres.com/shopdc/pic/8480d159-befe-42fa-9e1a-00506d908db0.jpg',
          title: '荣耀手表梦幻系列',
          desc: '轻薄潮美 | 一周长续航',
          sale: '预订499 3期免息',
          priceCurrency: '¥',
          priceAmount: '799',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res6.vmallres.com/shopdc/pic/cb3a6cc0-5db8-4d9e-8dcb-90b34b083b36.jpg',
          title: '荣耀xSport PRO蓝牙耳机',
          desc: '18小时长续航 | 5分钟快充',
          sale: '下单使用500以内积分可双倍抵现',
          priceCurrency: '¥',
          priceAmount: '399',
          priceFrom: '起'
        }
      ],
      goodsList4: [
        {
          Imgsrc:
            'https://res3.vmallres.com/shopdc/pic/5b88ce2d-32f6-4d84-9822-19914a5a81ed.jpg',
          title: '荣耀无线充电器',
          desc: '支持荣耀V30PRO及Mate30系列',
          sale: '最高补贴50元',
          priceCurrency: '¥',
          priceAmount: '199',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/shopdc/pic/268a2b10-b3b8-4d6c-8a8a-5a5e335b8215.jpg',
          title: '荣耀路由Pro 2',
          desc: '四核全千兆 | 凌霄双芯片',
          sale: '限时直降150元',
          priceCurrency: '¥',
          priceAmount: '199',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res8.vmallres.com/shopdc/pic/46afe39d-b166-4f0a-9920-e6cd1daa46c8.jpg',
          title: '荣耀充电器  快充版',
          desc: '支持V30系列 | 40W超级快充',
          sale: '暂无优惠',
          priceCurrency: '¥',
          priceAmount: '159',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res1.vmallres.com/shopdc/pic/543d78c4-ab73-46ce-87a1-db1390084026.jpg',
          title: '荣耀移动电源 2',
          desc: '10000mAh | 18W双向快充',
          sale: '多买多送',
          priceCurrency: '¥',
          priceAmount: '99',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res7.vmallres.com/shopdc/pic/321915e8-2da4-43a2-902a-37ab1f51fdce.jpg',
          title: '荣耀手环 5i',
          desc: '触控大彩屏 | USB随充',
          sale: '血氧检测 USB随充',
          priceCurrency: '¥',
          priceAmount: '159',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res6.vmallres.com/shopdc/pic/7f7b18cd-8f0e-417d-80c9-53505b7d614e.jpg',
          title: '荣耀魔方蓝牙音箱',
          desc: '大音量重低音 | 一手可握',
          sale: 'APP专享，最高补贴50元',
          priceCurrency: '¥',
          priceAmount: '99',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res3.vmallres.com/shopdc/pic/16384e51-b80a-4d44-bdf1-fce09c7bdc48.jpg',
          title: '荣耀MINI照片打印机',
          desc: '无墨打印 | 高清画质',
          sale: '限时直降300元',
          priceCurrency: '¥',
          priceAmount: '299',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res0.vmallres.com/shopdc/pic/fec1a870-8998-4eb1-8043-93fcd0a0408a.jpg',
          title: '荣耀路由2S',
          desc: '四颗独立信号放大器 | 双千兆',
          sale: '限时直降70元',
          priceCurrency: '¥',
          priceAmount: '129',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res8.vmallres.com/shopdc/pic/8cb303ac-4035-4352-bfc9-329ce966ade0.jpg',
          title: '荣耀小K 2',
          desc: '限时优惠50元',
          sale: '七重定位 高清通话',
          priceCurrency: '¥',
          priceAmount: '249',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res2.vmallres.com/shopdc/pic/d042a5d3-1bac-43db-90f2-e7bad25ee392.jpg',
          title: '荣耀手环4 Running版',
          desc: '专业跑姿监测 | 两种佩戴方式',
          sale: '让跑姿更专业',
          priceCurrency: '¥',
          priceAmount: '99',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res4.vmallres.com/shopdc/pic/2de47530-53cd-49c5-9d2b-6c191f9824dc.jpg',
          title: '荣耀手环5 篮球版',
          desc: '荣耀手环5 篮球版',
          sale: '专业篮球及跑姿监测',
          priceCurrency: '¥',
          priceAmount: '129',
          priceFrom: '起'
        },
        {
          Imgsrc:
            'https://res6.vmallres.com/shopdc/pic/bf82e4f7-aac4-4a50-b68b-5bed27eec475.jpg',
          title: '荣耀三脚架自拍杆',
          desc: '伸缩自如 | 轻松入镜',
          sale: '限时直降20元',
          priceCurrency: '¥',
          priceAmount: '99',
          priceFrom: '起'
        }
      ],
      btnList1: [
        {
          title: '荣耀手表2'
        },
        {
          title: '荣耀笔记本Pro 2020'
        },
        {
          title: '荣耀平板V6'
        }
      ],
      btnList2: [
        {
          title: '荣耀智能体脂秤2'
        },
        {
          title: '荣耀FlyPods3'
        },
        {
          title: '荣耀智慧屏X1'
        }
      ]
    }
  }
}
</script>
<style scoped>
.mainbanner {
  width: 100%;

  margin: 0 auto;
}

.mainbanner .layout {
  text-align: center;
}
.mainbanner .layout h1 {
  font-size: 30px;
  font-weight: 600;
  position: relative;
  margin: 48px 0;
}
.mainbanner .layout h1::before {
  content: '';
  width: 40px;
  height: 2px;
  position: absolute;
  bottom: -10px;
  left: 48%;
}
.mainbanner .contentCjxp {
  width: 1200px;
  height: 200px;
  margin: 0 0 0 0;
  background: url(https://res4.vmallres.com/shopdc/pic/8bba676f-0912-479a-9f1a-66b2f249a632.png)
    center no-repeat;
}
.mainbanner .contentCjxp1 {
  width: 1200px;
  height: 180px;
  margin: 0 0 0 0;
  background: url(https://res4.vmallres.com/shopdc/pic/cbbd0e70-4f9a-4470-957d-7dd90a58440f.png)
    center no-repeat;
}
.mainbanner .contentCjxp2 {
  width: 1200px;
  height: 580px;
  margin: 0 0 0 0;
  background: url(https://res5.vmallres.com/shopdc/pic/63cb042e-b62f-4781-9077-2b18953b1e65.png)
    center no-repeat;
}
.mainbanner .contentCjxp3 {
  width: 1200px;
  height: 350px;
  margin: 0 0 0 0;
  background: url(https://res6.vmallres.com/shopdc/pic/4b4f6280-8c67-4200-bb67-68bb78f43df6.png)
    center no-repeat;
}
.mainbanner .contentCjxp4 {
  width: 1200px;
  height: 130px;
  margin: 0 0 0 0;
  background: url(https://res9.vmallres.com/shopdc/pic/029e83a7-f4e5-4f25-9927-8b071f954631.png)
    center no-repeat;
}
.mainbanner .contentCjxp5 {
  width: 1200px;
  height: 130px;
  margin: 0 0 0 0;
  background: url(https://res6.vmallres.com/shopdc/pic/31247202-3fff-43c5-b230-4613dd549182.png)
    center no-repeat;
}
.mainbanner .contentCjxp6 {
  width: 1200px;
  height: 130px;
  margin: 0 0 0 0;
  background: url(https://res6.vmallres.com/shopdc/pic/0b378013-8581-4142-9d39-eea88eb27f2b.png)
    center no-repeat;
}
.mainbanner .contentCjxp7 {
  width: 1200px;
  height: 130px;
  margin: 0 0 0 0;
  background: url(https://res8.vmallres.com/shopdc/pic/fa4b088e-f5b7-4957-a145-0b5e6a326fca.png)
    center no-repeat;
}
.mainbanner .contentCjxp8 {
  width: 1200px;
  height: 130px;
  margin: 0 0 0 0;
  background: url(https://res4.vmallres.com/shopdc/pic/8106e75e-404e-4ca8-9a03-184a7b3d095f.png)
    center no-repeat;
}
.mainbanner .contentCjxp:hover {
  cursor: pointer;
}
.mainbanner .contentCjxp2:hover {
  cursor: pointer;
}
.grid-8 {
  width: 100%;
  height: 950px;
  margin-top: 20px;
}
.grid-8 ul {
  width: 100%;
  height: 940px;
  display: grid;
  grid-template-columns: repeat(4, 290px);
  grid-template-rows: repeat(2, 460px);
  justify-content: space-between;
  align-content: space-between;
}

.grid-8 ul li > a {
  display: block;
  height: 460px;
  position: relative;
  background-color: #fff;
}
.grid-8 ul li > a > p.pic {
  width: 290px;
  height: 290px;
  background-color: #ebeef3;
}
.grid-8 ul li > a > p.pic > img {
  width: 290px;
  height: 290px;
}

p.title {
  font-size: 22px;
  height: 30px;
  line-height: 30px;
  margin: 24px 15px 0 15px;
  color: #000;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
p.desc {
  font-size: 16px;
  height: 22px;
  line-height: 22px;
  margin: 5px 15px 0 15px;
  color: #666;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.grid-8 ul li > a > p.sale {
  position: absolute;
  left: 0;
  top: 262px;
  background-color: #458be6;
  max-width: 260px;
  height: 28px;
  line-height: 28px;
  font-size: 16px;
  color: #fff;
  border-radius: 14px 14px 14px 0;
  padding-left: 10px;
  padding-right: 15px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.price-wrp {
  margin-top: 20px;
  text-align: center;
}
p.tip {
  width: 72px;
  height: 72px;
  float: left;
  position: absolute;
  top: 5px;
  right: 5px;
}
.price-wrp p.price {
  border-radius: 18px;
  width: 130px;
  height: 36px;
  line-height: 36px;
  display: inline-block;
  background-color: black;
}
.price-wrp p.price .price-currency,
.price-wrp p.price .price-from {
  font-size: 14px;
}
.price-wrp p.price .price-amount {
  font-size: 22px;
  font-weight: bold;
  max-width: 122px;
  overflow: hidden;
  white-space: nowrap;
}

.grid-12 {
  width: 100%;
  height: 1410px;
  margin-top: 20px;
}
.grid-12 ul {
  width: 100%;
  height: 1410px;
  display: grid;
  grid-template-columns: repeat(4, 290px);
  grid-template-rows: repeat(3, 460px);
  justify-content: space-between;
  align-content: space-between;
}

.grid-12 ul li > a {
  display: block;
  height: 460px;
  position: relative;
  background-color: #fff;
}
.grid-12 ul li > a > p.pic {
  width: 290px;
  height: 290px;
  background-color: #ebeef3;
}
.grid-12 ul li > a > p.pic > img {
  width: 290px;
  height: 290px;
}
.grid-12 ul li > a > p.sale {
  position: absolute;
  left: 0;
  top: 262px;
  background-color: #458be6;
  max-width: 365px;
  height: 28px;
  line-height: 28px;
  font-size: 16px;
  color: #fff;
  border-radius: 14px 14px 14px 0;
  padding-left: 10px;
  padding-right: 15px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.mainbanner .contentCjxp9 {
  width: 1200px;
  height: 510px;
  margin: 0 0 0 0;
  background: url(https://res1.vmallres.com/shopdc/pic/a730d9de-b3b3-4842-9f84-ee6f657bd6dd.png)
    center no-repeat;
}
.mainbanner .contentCjxp10 {
  width: 1200px;
  height: 130px;
  margin: 0 0 0 0;
  background: url(https://res8.vmallres.com/shopdc/pic/6a8a41e7-fef0-4e29-aab0-1d88b737aca1.png)
    center no-repeat;
}
</style>
