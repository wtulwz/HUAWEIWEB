<template>
  <div style="background:white">
    <div style="width:100%;height:577px">
      <img
        src="https://res0.vmallres.com/shopdc/pic/04941534-23a4-4fa2-b8eb-d4b6e22fdcfa.jpg"
        style="width:100%"
      />
    </div>
    <a href="#t"> <div class="backtop"></div></a>
    <a
      href="https://www.vmall.com/notice-10910?f7w5kPoBj9p2JQMy36Xp43oM696YLTa4"
      ><div class="more"></div
    ></a>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped>
.backtop {
  position: absolute;
  width: 234px;
  height: 200px;
  margin-top: -570px;
  margin-left: 500px;
}
.more {
  position: absolute;
  width: 234px;
  height: 200px;
  margin-top: -570px;
  margin-left: 800px;
}
</style>
