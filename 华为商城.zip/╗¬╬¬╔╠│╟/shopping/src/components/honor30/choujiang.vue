<template>
  <div class="bigdiv">
    <div class="topdiv">
      <img
        src="https://res5.vmallres.com/shopdc/pic/4fb39251-9ef9-4e89-ae36-0aaecfadb2c0.jpg"
      />
    </div>
    <div class="bottomdiv">
      <div id="choujiang">
        <div style="width: 1260px;height:600px;margin: 0 auto; ">
          <div style="width:730px;height:550px;float: left">
            <div class="fanpai">
              <ul>
                <li v-for="(item, index) in wupin1" :key="index">
                  <div :class="item.wupinclass"></div>
                </li>
                <li>
                  <div class="wupindiv4"></div>
                </li>
                <li>
                  <a @click="qiehuan"
                    ><div
                      v-bind:class="{
                        wupindiv5: ys5,
                        wupindivfan2: fan2
                      }"
                    ></div
                  ></a>
                </li>
                <li>
                  <div class="wupindiv6"></div>
                </li>
                <li v-for="(item, index) in wupin2" :key="'index_' + index">
                  <div :class="item.wupinclass"></div>
                </li>
              </ul>
            </div>
          </div>
          <div
            style="width:400px;height:500px;float: left;background: white;margin-left:50px;border-radius: 15px; "
          >
            <h1 style="margin-top: 40px;">活动规则</h1>
            <div style="width: 300px;margin: 0 auto ;margin-top: 10px;">
              <p style="font-size: 15px;">
                1、活动时间：2020年8月1日00:00-8月31日23:59
              </p>
            </div>
            <div style="width: 300px;margin: 0 auto ;margin-top: 10px;">
              <p style="font-size: 15px;">
                2、活动规则：活动期间用户登陆华为商城帐号，进入活动页面，点击参与抽奖，同一帐号每天有3次免费抽奖机会，抽奖机会当天有效不累计。活动页面翻牌抽奖奖品及次...
              </p>
            </div>
            <div style="width: 300px;margin: 0 auto ;margin-top: 10px;">
              <button
                style="font-size: 15px;color: red;border-style: none;background: transparent;outline: none;"
                id="triggerBtn"
                @click="tan"
              >
                更多详情>
              </button>
            </div>

            <h1 style="margin-top: 40px;">中奖名单</h1>

            <div id="b">
              <ul id="ul1" :class="{ anim: animate == true }">
                <li
                  v-for="(item, index) in mingdan"
                  :key="index"
                  @click="roll(50)"
                >
                  {{ item.name }}
                </li>
              </ul>
              <ul id="ul2"></ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="myModal" class="modal">
      <div class="modal-content">
        <button class="close" id="closeBtn">X</button>
        <p style="font-size:34px;color: rgb(192, 101, 101);">活动规则</p>
        <p style="font-size:34px;color: rgb(192, 101, 101);">
          __________________________________
        </p>
        <div class="modal-body">
          <p
            style="font-size: 16px;color: rgb(131, 130, 130); line-height: 30px;"
          >
            1、活动时间：2020年7月1日00:00-7月31日23:59<br />
            2、活动规则：活动期间用户登陆华为商城帐号，进入活动页面，点击参与抽奖，
            同一帐号每天有3次免费抽奖机会，抽奖机会当天有效不累计。活动页面翻牌抽奖奖品及次数共享。<br />
            3、奖品设置：<br />
            一等奖（5名）： 华为40W超级快充移动电源 1个<br />
            二等奖（10名）：力博得智能声波牙刷 优漾 1个<br />
            三等奖（10名）：华为三脚架自拍杆 1个<br />
            四等奖（10名）：荣耀手环4 Running版 1个<br />
            五等奖（11名）：游戏手办 1个<br />
            幸运奖（200,000名）：华为品牌优惠券 1张<br />
            幸运奖（200,000名）：荣耀品牌优惠券 1张<br />
            4、奖品发放：用户抽奖完毕后即在本抽奖活动页面被告知抽奖结果。
            实物中奖用户将会收到消息通知，PC端的查看路径：在我的帐号>消息中心>活动消息，
            手机端的查看路径为：点击华为商城APP端首页搜索栏右侧的小图标，进入消息中心，
            查看活动消息，或者进入商城>我的>右上角消息中心。优惠券将在中奖15分钟内发至用户帐户，
            请在华为商城-我的-优惠券中查看，优惠券具体的使用规则和限制详见券面说明，
            可使用优惠券的商品见券面“去使用”商品列表。抽中实物奖品用户请于2020年8月1日
            前到“个人中心-收货地址管理”中设置默认收货地址，实物奖品将在活动结束后15-20个工作日
            内按照您的默认收货地址发货，具体版本/制式/颜色请以收到的实物为准。<br />
            温馨提示：请中奖用户保持联系电话畅通，如因用户原因导致奖品发放失败的视为自动放弃奖品。
            如出现恶意刷单的情况，华为商城将保留拒绝发放或收回奖品的权利。
            任何人通过不正当手段（包括但不限于侵犯第三人合法权益、作弊、扰乱系统、
            实施网络攻击、批量注册、用机器注册账户、用机器模拟客户端等方式）获得本次活动利益的，
            华为商城有权拒绝发放奖品或撤销用户所获利益并要求赔偿相关损失 。
          </p>
        </div>
        <br />
        <br />
        <button class="close2" id="closeBtn2">
          知道了
        </button>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      animate: false,
      mingdan: [
        { name: '' },
        { name: '' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' },
        { name: '150****3421 抽中 荣耀品牌 10元优惠券' }
      ],
      wupin1: [
        {
          img:
            'https://res9.vmallres.com/shopdc/pic/8bf32c85-4d7d-4036-8d88-b0e2bd8767ca.png',
          wupinclass: 'wupindiv1'
        },
        {
          img:
            'https://res5.vmallres.com/shopdc/pic/a38461b2-8317-4a66-877a-ee3d1ed8ea27.png',
          wupinclass: 'wupindiv2'
        },
        {
          img:
            'https://res1.vmallres.com/shopdc/pic/1a70c905-20c6-46d5-a7c3-2c14a36a0c68.png',
          wupinclass: 'wupindiv3'
        }
      ],
      wupin2: [
        {
          img:
            'https://res5.vmallres.com/shopdc/pic/d2837dac-2c7e-40db-ac19-592fb53c858f.png',
          wupinclass: 'wupindiv7'
        },
        {
          img:
            'https://res9.vmallres.com/shopdc/pic/6c0d6c7c-ec37-4a1c-90bc-fc211be61a2c.png',
          wupinclass: 'wupindiv8'
        },
        {
          img:
            'https://res8.vmallres.com/shopdc/pic/0d6e798a-4b47-4146-b3a1-bd95d59fa793.png',
          wupinclass: 'wupindiv9'
        }
      ],
      ys1: true,
      ys2: true,
      ys3: true,
      ys4: true,
      ys5: true,
      ys6: true,
      ys7: true,
      ys8: true,
      ys9: true,
      fan: false,
      fan2: false
    }
  },
  created() {
    setInterval(this.scroll, 1000)
  },
  methods: {
    tan() {
      var modalBox = {}

      modalBox.modal = document.getElementById('myModal')

      modalBox.triggerBtn = document.getElementById('triggerBtn')

      modalBox.closeBtn = document.getElementById('closeBtn')
      modalBox.closeBtn2 = document.getElementById('closeBtn2')

      modalBox.show = function() {
        console.log(this.modal)
        this.modal.style.display = 'block'
      }

      modalBox.close = function() {
        this.modal.style.display = 'none'
      }
      modalBox.close2 = function() {
        this.modal.style.display = 'none'
      }

      modalBox.outsideClick = function() {
        var modal = this.modal
        window.onclick = function(event) {
          if (event.target == modal) {
            modal.style.display = 'none'
          }
        }
      }

      modalBox.init = function() {
        var that = this
        this.triggerBtn.onclick = function() {
          that.show()
        }
        this.closeBtn.onclick = function() {
          that.close()
        }
        this.closeBtn2.onclick = function() {
          that.close2()
        }
        this.outsideClick()
      }
      modalBox.init()
    },
    scroll() {
      this.animate = true
      setTimeout(() => {
        this.mingdan.push(this.mingdan[0])
        this.mingdan.shift()
        this.animate = false
      }, 500)
    },
    qiehuan() {
      this.ys1 = !this.ys1
      this.fan = !this.fan

      this.ys5 = !this.ys5
      this.fan2 = !this.fan2
    }
  }
}
</script>
<style scoped>
.anim {
  transition: all 1s;
  margin-top: -40px;
}

.bigdiv {
  background: rgb(234, 234, 248);
  height: 750px;
}
.topdiv {
  width: 100%;
  height: 120px;
}
.topdiv img {
  width: 100%;
  height: 120px;
}
#b {
  margin: 0 auto;
  margin-top: 20px;
  width: 230px;
  height: 140px;
  overflow: hidden;
  text-align: center;
}

#b li {
  font-size: 16px;
  height: 43px;
}
.button {
  outline: none;
  margin: 0 auto;
  float: left;
  width: 170px;
  height: 35px;
  border: 1px solid black;
  border-radius: 17.5px;
  text-align: center;
  margin-top: 60px;
}
.button p {
  font-size: 16px;
  margin-top: 8px;
}
.button2 {
  outline: none;
  margin: 0 auto;
  float: left;
  width: 170px;
  height: 35px;
  border: 1px solid black;
  border-radius: 17.5px;
  text-align: center;
  margin-top: 60px;
}
.button2 p {
  font-size: 16px;
  margin-top: 8px;
}
.modal {
  display: none;
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.4);
}
.modal-body {
  width: 500px;
  height: 300px;
  margin: 0 auto;
  margin-top: 20px;
  overflow: scroll;
  text-align: left;
}
.modal-body::-webkit-scrollbar {
  width: 0px;
  height: 1px;
}
.modal-body::-webkit-scrollbar-thumb {
  border-radius: 5px;
  box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
  background: rgba(0, 0, 0, 0.2);
}
/*弹框内容*/
.modal-content {
  border: 11px solid rgb(226, 151, 98);
  border-radius: 15px;
  display: flex;
  flex-direction: column;
  position: relative;
  background-color: #fefefe;
  margin: 6% auto;
  text-align: center;
  width: 700px;
  height: 600px;
  animation: topDown 0.4s;
  z-index: 66666;
}
@keyframes topDown {
  from {
    top: -100px;
    opacity: 0;
  }
  to {
    top: 0;
    opacity: 1;
  }
}
/*弹框头部*/
.modal-header {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
}
/*关闭X样式*/
.modal-content .close {
  outline: none;
  color: #aaa;
  float: left;
  margin-top: 15px;
  margin-left: 645px;
  font-size: 25px;
  font-weight: bold;
  z-index: 111;
  width: 30px;
  border-style: none;
  background: transparent;
}
.modal-content .close:hover {
  color: black;
  text-decoration: none;
  cursor: pointer;
}
.modal-content .close2 {
  outline: none;
  color: white;
  float: left;
  margin-top: 5px;
  font-size: 25px;
  font-weight: bold;
  z-index: 111;
  width: 180px;
  height: 45px;
  border-style: none;
  background: transparent;
  margin: 0 auto;
  border-radius: 22.5px;
  background: rgb(226, 151, 98);
}

.fanpai {
  width: 700px;
  height: 520px;
  margin: auto;
}

.fanpai li {
  float: left;
  margin-bottom: 18px;
}
.wupindiv1 {
  width: 220px;
  height: 160px;
  margin-right: 13px;
  background: url(https://res9.vmallres.com/shopdc/pic/8bf32c85-4d7d-4036-8d88-b0e2bd8767ca.png);
  background-size: 100%;
}

.wupindiv2 {
  width: 220px;
  height: 160px;
  background: url(https://res5.vmallres.com/shopdc/pic/a38461b2-8317-4a66-877a-ee3d1ed8ea27.png);
  background-size: 100%;
  margin-right: 13px;
}

.wupindiv3 {
  width: 220px;
  height: 160px;
  background: url(https://res1.vmallres.com/shopdc/pic/1a70c905-20c6-46d5-a7c3-2c14a36a0c68.png);
  background-size: 100%;
  margin-right: 13px;
}

.wupindiv4 {
  width: 220px;
  height: 160px;
  background: url(https://res8.vmallres.com/shopdc/pic/98b26dbb-a506-41ca-afeb-0d78312839b2.png);
  background-size: 100%;
  margin-right: 13px;
}

.wupindiv5 {
  width: 220px;
  height: 160px;
  background: url(https://res0.vmallres.com/shopdc/pic/7848e6d2-8420-410e-893d-fbd3b9ac1e78.png)
    no-repeat;
  background-position: center;
  background-size: 160px 160px;
  margin-right: 13px;
}

.wupindiv6 {
  width: 220px;
  height: 160px;
  background: url(https://res4.vmallres.com/shopdc/pic/ef1e4f17-3fba-45fc-9fb5-6f65c7dbfe01.png);
  background-size: 100%;
  margin-right: 13px;
}

.wupindiv7 {
  width: 220px;
  height: 160px;
  background: url(https://res5.vmallres.com/shopdc/pic/d2837dac-2c7e-40db-ac19-592fb53c858f.png);
  background-size: 100%;
  margin-right: 13px;
}

.wupindiv8 {
  width: 220px;
  height: 160px;
  background: url(https://res9.vmallres.com/shopdc/pic/6c0d6c7c-ec37-4a1c-90bc-fc211be61a2c.png);
  background-size: 100%;
  margin-right: 13px;
}

.wupindiv9 {
  width: 220px;
  height: 160px;
  background: url(https://res8.vmallres.com/shopdc/pic/0d6e798a-4b47-4146-b3a1-bd95d59fa793.png);
  background-size: 100%;
  margin-right: 13px;
}
.wupindivfan {
  width: 220px;
  height: 160px;
  margin-right: 13px;
  background: url(https://res0.vmallres.com/shopdc/pic/193f6450-5327-444e-a610-88125afb4ba7.png);
  background-size: 100%;
}
.wupindivfan2 {
  width: 220px;
  height: 160px;
  margin-right: 13px;
  background: url(https://res7.vmallres.com/shopdc/pic/9c9af0eb-4c3d-4053-ae33-fd5f3fe90492.png)
    no-repeat;
  background-position: center;
  background-size: 160px 160px;
}
</style>
