<template>
  <div class="bigdiv">
    <div class="topdiv">
      <img
        src="https://res1.vmallres.com/shopdc/pic/4ac9f87e-196e-466d-8b86-477571a9bb4e.jpg"
      />
    </div>
    <div class="bottomdiv">
      <ul>
        <li v-for="(item, index) in two" :key="index">
          <a :href="item.url">
            <img :src="item.imgurl" />
            <div style="background:white;height:170px;margin-top:-5px">
              <p class="p_title">{{ item.title }}</p>
              <p class="p_text">{{ item.text }}</p>
              <div class="bottom_btn">
                <span class="s1">¥</span>
                <p class="p_price">{{ item.price }}</p>
                <span class="s2">起</span>
              </div>
            </div>
            <div class="youhui">{{ item.youhui }}</div>
          </a>
        </li>
      </ul>
    </div>
    <div class="bottomdiv2">
      <ul>
        <li v-for="(item, index) in three" :key="index">
          <a :href="item.url">
            <img :src="item.imgurl" />
            <div style="background:white;height:170px;margin-top:-5px">
              <p class="p_title2">{{ item.title }}</p>
              <p class="p_text2">{{ item.text }}</p>
              <div class="bottom_btn2">
                <span class="s12">¥</span>
                <p class="p_price2">{{ item.price }}</p>
                <span class="s22">起</span>
              </div>
            </div>
            <div class="youhui2">{{ item.youhui }}</div>
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      two: [
        {
          url:
            'https://www.vmall.com/product/10086790354335.html#10086582958325',
          imgurl:
            'https://res9.vmallres.com/shopdc/pic/8b03500f-d93c-463b-89db-91a78dbae171.png',
          youhui: 'APP专享，最高补贴500元',
          title: '荣耀MagicBook 14 2020',
          text: '微边全面屏 | AMD锐龙处理器',
          price: '2699'
        },
        {
          url:
            'https://www.vmall.com/product/10086758312626.html#10086363115121',
          imgurl:
            'https://res9.vmallres.com/shopdc/pic/03a7b70f-1cc5-4d1a-a0eb-8d7d4e0e795a.png',
          youhui: '',
          title: '荣耀平板6 10.1英寸',
          text: '双重护眼认证 | 双喇叭立体声',
          price: '1399'
        }
      ],
      three: [
        {
          url:
            'https://www.vmall.com/product/10086403884951.html#10086254002438',
          imgurl:
            'https://res8.vmallres.com/pimages//product/6972453167880/428_428_402A96A0183A6ACBF7A0E15B06C8C8ED98E1750C9D6A122Dmp.png',
          youhui: '限时优惠200元',
          title: '荣耀 MagicBook Pro 2020',
          text: '16.1英寸理想屏 | AMD锐龙处理器',
          price: '4499'
        },
        {
          url:
            'https://www.vmall.com/product/10086588430759.html#10086042793877',
          imgurl:
            'https://res8.vmallres.com/shopdc/pic/9653bcf3-07e5-4ca2-ace5-18dbcc9806bc.jpg',
          youhui: '支付后赠送超值权益礼包',
          title: '荣耀MagicBook 15 2020',
          text: '微边全面屏 | AMD锐龙处理器',
          price: '3599'
        },
        {
          url:
            'https://www.vmall.com/product/10086842533081.html#10086832186721',
          imgurl:
            'https://res5.vmallres.com/shopdc/pic/7c9b6c9c-5d20-407d-9fad-5d9386c66249.png',
          youhui: '预订最高优惠300元',
          title: '荣耀智慧屏X1系列 50英寸',
          text: '4K超清全面屏 8K解码',
          price: '1999'
        }
      ]
    }
  },
  methods: {}
}
</script>
<style scoped>
.bigdiv {
  background: rgb(234, 234, 248);
  height: 1200px;
}
.topdiv {
  width: 100%;
  height: 120px;
}
.topdiv img {
  width: 100%;
  height: 120px;
}
.bottomdiv {
  width: 1200px;
  height: 470px;
  margin: 0 auto;
}
.bottomdiv li {
  float: left;
  width: 590px;
  height: 460px;
  margin-right: 10px;
  margin-bottom: 10px;
}
.bottomdiv img {
  width: 590px;
  height: 290px;
}
.p_title {
  color: #222222;
  font-size: 22px;
  padding-top: 24px;
  line-height: 30px;
  text-align: center;
}
.p_text {
  color: #666666;
  font-size: 16px;
  line-height: 22px;
  text-align: center;
  padding-top: 5px;
}
.bottom_btn {
  width: 130px;
  height: 36px;
  border-radius: 18px;
  background: #222222;
  margin: auto;
  margin-top: 20px;
  color: white;
  padding-left: 10px;
  padding-right: 10px;
  text-align: center;
}
.s1 {
  padding-top: 10px;
  float: left;
  font-size: 14px;
  padding-left: 10px;
  padding-right: 5px;
}
.s2 {
  padding-top: 10px;
  padding-left: 5px;
  padding-right: 10px;
  float: left;
  font-size: 14px;
}
.p_price {
  float: left;
  padding-top: 3px;
  text-align: center;
  font-size: 22px;
  font-weight: bold;
}
.youhui {
  position: absolute;
  height: 28px;
  color: white;
  background: #e16773;
  padding-left: 15px;
  padding-right: 15px;
  text-align: center;
  border-top-left-radius: 14px;
  border-top-right-radius: 14px;
  border-bottom-right-radius: 14px;
  padding-top: 3px;
  margin-top: -198px;
}

.bottomdiv2 {
  width: 1200px;
  height: 560px;
  margin: 0 auto;
}
.bottomdiv2 li {
  float: left;
  width: 390px;
  height: 560px;
  margin-right: 10px;
  margin-bottom: 10px;
}
.bottomdiv2 img {
  width: 390px;
  height: 390px;
}
.p_title2 {
  color: #222222;
  font-size: 22px;
  padding-top: 24px;
  line-height: 30px;
  text-align: center;
}
.p_text2 {
  color: #666666;
  font-size: 16px;
  line-height: 22px;
  text-align: center;
  padding-top: 5px;
}
.bottom_btn2 {
  width: 130px;
  height: 36px;
  border-radius: 18px;
  background: #222222;
  margin: auto;
  margin-top: 20px;
  color: white;
  padding-left: 10px;
  padding-right: 10px;
  text-align: center;
}
.s12 {
  padding-top: 10px;
  float: left;
  font-size: 14px;
  padding-left: 10px;
  padding-right: 5px;
}
.s22 {
  padding-top: 10px;
  padding-left: 5px;
  padding-right: 10px;
  float: left;
  font-size: 14px;
}
.p_price2 {
  float: left;
  padding-top: 3px;
  text-align: center;
  font-size: 22px;
  font-weight: bold;
}
.youhui2 {
  position: absolute;
  height: 28px;
  color: white;
  background: #e16773;
  padding-left: 15px;
  padding-right: 15px;
  text-align: center;
  border-top-left-radius: 14px;
  border-top-right-radius: 14px;
  border-bottom-right-radius: 14px;
  padding-top: 3px;
  margin-top: -198px;
}
</style>
