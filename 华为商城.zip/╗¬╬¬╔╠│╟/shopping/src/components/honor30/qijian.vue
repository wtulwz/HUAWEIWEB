<template>
  <div class="bigdiv">
    <div class="topdiv">
      <img
        src="https://res5.vmallres.com/shopdc/pic/5d8225f0-b8d7-45b2-b717-ea6569f81335.jpg"
      />
    </div>
    <div class="bottomdiv">
      <ul>
        <li v-for="(item, index) in phone" :key="index">
          <a :href="item.url">
            <img :src="item.imgurl" />
            <div style="background:white;height:170px;margin-top:-5px">
              <p class="p_title">{{ item.title }}</p>
              <p class="p_text">{{ item.text }}</p>
              <div class="bottom_btn">
                <span class="s1">¥</span>
                <p class="p_price">{{ item.price }}</p>
                <span class="s2">起</span>
              </div>
            </div>
            <div class="youhui">{{ item.youhui }}</div>
          </a>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      phone: [
        {
          url:
            'https://www.vmall.com/product/10086557426930.html#10086183393765',
          imgurl:
            'https://res3.vmallres.com/shopdc/pic/91102f99-fa25-4c7e-934f-33595ea3e49a.jpg',
          youhui: '最高省410元|部分赠配件|免息',
          title: '荣耀30',
          text: '50倍超稳远摄 超感光高清夜拍',
          price: '2699'
        },
        {
          url:
            'https://www.vmall.com/product/10086054969281.html#10086530981614',
          imgurl:
            'https://res1.vmallres.com/shopdc/pic/c2b111a8-0ca1-4a96-a927-fb98f2e54593.jpg',
          youhui: 'APP专享，最高补贴400元',
          title: '荣耀30 Pro',
          text: '双模5G 麒麟990 5G SoC',
          price: '3999'
        },
        {
          url:
            'https://www.vmall.com/product/10086024821187.html#10086433871491',
          imgurl:
            'https://res1.vmallres.com/shopdc/pic/a8385fa4-e2a4-4f96-a377-d5f7baf55307.jpg',
          youhui: '限量送移动电源',
          title: '荣耀30S',
          text: '麒麟820 5G SoC 3倍光学变焦',
          price: '2099'
        },
        {
          url:
            'https://www.vmall.com/product/10086664213829.html#10086739775099',
          imgurl:
            'https://res0.vmallres.com/shopdc/pic/b86c97d4-8951-4c26-ba3a-0da6dab6c229.png',
          youhui: '高感光超清美拍',
          title: '荣耀30青春版',
          text: '6期免息|享多重好礼',
          price: '1699'
        },
        {
          url:
            'https://www.vmall.com/product/10086091329647.html#10086330060203',
          imgurl:
            'https://res2.vmallres.com/shopdc/pic/e77e46d1-d25e-48f5-97f0-ee2fb6aaca11.png',
          youhui: '超能大屏 5G风暴',
          title: '荣耀X10 Max',
          text: '12期免息',
          price: '2099'
        },
        {
          url:
            'https://www.vmall.com/product/10086397382774.html#10086749337992',
          imgurl:
            'https://res0.vmallres.com/shopdc/pic/94fe7e3f-b3fa-4f21-9978-a7eb9619646a.png',
          youhui: '享12期免息',
          title: '荣耀X10',
          text: '麒麟820双模5G九频',
          price: '1899'
        },
        {
          url:
            'https://www.vmall.com/product/10086525758727.html#10086902309741',
          imgurl:
            'https://res5.vmallres.com/shopdc/pic/cfaa6e34-657e-4e51-a5f9-4e9d91e2a3fa.jpg',
          youhui: '限时优惠110+6期免息',
          title: '荣耀Play4',
          text: '6400万锐力四摄',
          price: '1899'
        },
        {
          url:
            'https://www.vmall.com/product/10086815210410.html#10086738236116',
          imgurl:
            'https://res9.vmallres.com/shopdc/pic/557a70a1-3f8a-4387-8249-9a5630c47459.jpg',
          youhui: '最高优惠410',
          title: '荣耀Play4 Pro',
          text: '麒麟990 40W超级快充',
          price: '2499'
        }
      ]
    }
  },
  methods: {}
}
</script>
<style scoped>
.bigdiv {
  background: rgb(234, 234, 248);
  height: 1100px;
}
.topdiv {
  width: 100%;
  height: 120px;
}
.topdiv img {
  width: 100%;
  height: 120px;
}
.bottomdiv {
  width: 1200px;
  height: 470px;
  margin: 0 auto;
}
.bottomdiv li {
  float: left;
  width: 290px;
  height: 460px;
  margin-right: 10px;
  margin-bottom: 10px;
}
.bottomdiv img {
  width: 290px;
  height: 290px;
}
.p_title {
  color: #222222;
  font-size: 22px;
  padding-top: 24px;
  line-height: 30px;
  text-align: center;
}
.p_text {
  color: #666666;
  font-size: 16px;
  line-height: 22px;
  text-align: center;
  padding-top: 5px;
}
.bottom_btn {
  width: 130px;
  height: 36px;
  border-radius: 18px;
  background: #222222;
  margin: auto;
  margin-top: 20px;
  color: white;
  padding-left: 10px;
  padding-right: 10px;
  text-align: center;
}
.s1 {
  padding-top: 10px;
  float: left;
  font-size: 14px;
  padding-left: 10px;
  padding-right: 5px;
}
.s2 {
  padding-top: 10px;
  padding-left: 5px;
  padding-right: 10px;
  float: left;
  font-size: 14px;
}
.p_price {
  float: left;
  padding-top: 3px;
  text-align: center;
  font-size: 22px;
  font-weight: bold;
}
.youhui {
  position: absolute;
  height: 28px;
  color: white;
  background: #e16773;
  padding-left: 15px;
  padding-right: 15px;
  text-align: center;
  border-top-left-radius: 14px;
  border-top-right-radius: 14px;
  border-bottom-right-radius: 14px;
  padding-top: 3px;
  margin-top: -198px;
}
</style>
