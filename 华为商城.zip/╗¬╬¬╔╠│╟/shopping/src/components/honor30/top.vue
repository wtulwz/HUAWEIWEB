<template>
  <div id="t" style="background: white">
    <div class="topdiv">
      <div class="leftdiv">
        <a href="https://sale.vmall.com/honor.html">
          <img
            src="https://res.vmallres.com/pimages//common/config/logo/SXppnESYv4K11DBxDFc2.png"
        /></a>
      </div>
      <div class="rightdiv">
        <ul>
          <li>
            <a href="https://www.vmall.com/product/10086397382774.html"
              >荣耀X10</a
            >
          </li>
          <li>
            <a href="https://www.vmall.com/product/10086024821187.html"
              >荣耀30S</a
            >
          </li>
        </ul>
        <div class="rr">
          <img
            src="https://res2.vmallres.com/shopdc/pic/7668c450-cad6-48d3-a830-b6e2696dcab5.png"
            style="float: left;padding-top:5px"
          />
          <div style="float:left;">登录&nbsp;|&nbsp;注册</div>
        </div>
      </div>
    </div>
    <a href="https://www.vmall.com/product/10086557426930.html"
      ><div style="width:100%;margin-bottom:-10px">
        <img
          src="https://res1.vmallres.com/shopdc/pic/fa40030d-862b-4742-9990-4d6339e296fe.jpg"
          style="width:100%"
        /></div
    ></a>
    <a href="https://sale.vmall.com/yjhxryzc3.html"
      ><div style="width:100%; margin-bottom:-10px">
        <img
          src="https://res2.vmallres.com/shopdc/pic/59330477-8bb5-426c-8ad8-2118cb14f055.jpg"
          style="width:100%"
        /></div
    ></a>
    <a href="https://www.vmall.com/product/10086557426930.html"
      ><div style="width:100%; margin-bottom:-10px">
        <img
          src="https://res8.vmallres.com/shopdc/pic/d7d988ff-9363-479e-9f56-59e800d573a7.jpg"
          style="width:100%"
        /></div
    ></a>
    <a href="https://www.vmall.com/product/10086054969281.html"
      ><div style="width:100%;margin-bottom:-10px ">
        <img
          src="https://res9.vmallres.com/shopdc/pic/be2d7cc6-c06b-42e6-8cce-a58c09cc6a70.jpg"
          style="width:100%"
        /></div
    ></a>
  </div>
</template>
<script>
export default {
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped>
.topdiv {
  width: 1200px;
  margin: auto;
}
.leftdiv {
  width: 200px;
  height: 60px;
  float: left;
}
.leftdiv img {
  padding-top: 10px;
  width: 200px;
  height: 45px;
}
.rightdiv {
  width: 313px;
  float: right;
}
.rightdiv li {
  float: left;
  color: rgb(0, 0, 0);
  padding: 28px 6px 0px;
  font-size: 18px;
}
.rightdiv a:hover {
  text-decoration: underline;
  color: black;
}
.rr {
  float: left;
  font-size: 18px;
  margin-top: 27px;
  margin-left: 40px;
}
.rr li {
  float: left;
  color: rgb(0, 0, 0);
  padding: 28px 6px 0px;
  font-size: 18px;
}
</style>
