<template>
  <div>
    <!--公告-->
    <div class="lastNav">
      <ul>
        <li class="first">
          <img
            src="../../assets/HUAWEI_CSS_js_img/images/img_not_logged_in.png"
            alt="图片"
          />
          <div class="navWord">
            <span>你好！请 </span>
            <a href="https://www.vmall.com/?cid=9211">
              <p>登录 / 注册</p>
            </a>
          </div>
          <div class="imgWord">
            <a><span>新人福利</span></a>
            <a>
              <p>会员频道</p>
            </a>
          </div>
        </li>
        <li class="second">
          <ul>
            <li>
              <a href="http://company.vmall.com/client.html">
                <div class=" background1">
                  <img
                    src="../../assets/HUAWEI_CSS_js_img/images/img/企业.png"
                  />
                </div>
                <br />
                <div class="lWords"><span>企业购特惠</span></div>
              </a>
              <a href="http://company.vmall.com/client.html">
                <div class="background3">
                  <img
                    src="../../assets/HUAWEI_CSS_js_img/images/img/购物券.png"
                  />
                </div>
                <br />
                <div class="lWords"><span>会员领券</span></div>
              </a>
              <a href="http://company.vmall.com/client.html">
                <div class="background2">
                  <img
                    src="../../assets/HUAWEI_CSS_js_img/images/img/以旧换新.png"
                  />
                </div>
                <br />
                <div class="lWords"><span>以旧换新</span></div>
              </a>

              <a href="http://company.vmall.com/client.html">
                <div class="background4">
                  <img
                    src="../../assets/HUAWEI_CSS_js_img/images/img/p40.png"
                  />
                </div>
                <br />
                <div class="lWords"><span>P40 Pro+</span></div>
              </a>
              <a href="http://company.vmall.com/client.html">
                <div class="background5">
                  <img
                    src="../../assets/HUAWEI_CSS_js_img/images/img/数码1.png"
                  />
                </div>
                <br />
                <div class="lWords"><span>华为数码</span></div>
              </a>
              <a href="http://company.vmall.com/client.html">
                <div class="background6">
                  <img
                    src="../../assets/HUAWEI_CSS_js_img/images/img/数码2.png"
                  />
                </div>
                <br />
                <div class="lWords"><span>荣耀数码</span></div>
              </a>
            </li>
          </ul>
        </li>
        <li class="third">
          <div class="thirdContainer">
            <div class="rotationTip">
              <span>公告</span>
            </div>
            <div class="notice">
              <img
                src="../../assets/HUAWEI_CSS_js_img/images/img/二维码.png"
                class="i1"
              /><span>优购码</span>
              <img
                src="../../assets/HUAWEI_CSS_js_img/images/img/电池.png"
                class="i2"
              /><span>更换电池</span>
              <img
                src="../../assets/HUAWEI_CSS_js_img/images/img/保障.png"
                class="i3"
              /><span>补购保障</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
export default {
  name: 'lastNav',
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped>
icon {
  width: 1em;
  height: 1em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
</style>
