<template>
  <div>
    <div class="right">
      <ul>
        <li v-for="(rightnav, index) in right" :key="index">
          <a :href="rightnav.sourceUrl"
            ><div class="right_child">
              <i :class="rightnav.icons"></i><br />
            </div>
            <div class="right_left" v-if="rightnav.show">
              <div style="width:80px;margin:auto ">
                <p>{{ rightnav.text }}</p>
              </div>
            </div>
          </a>
        </li>
      </ul>
    </div>
    <a href="#top"
      ><div class="right_bottom" v-if="top" @click="tops()">
        <i class="el-icon-top"></i><br /></div
    ></a>
  </div>
</template>
<script>
export default {
  data() {
    return {
      right: [
        {
          icons: 'el-icon-shopping-cart-2',
          text: '购物车',
          show: true
        },
        {
          icons: 'el-icon-service',
          text: '人工客服',
          show: true
        },
        {
          icons: 'el-icon-collection',
          text: '自助服务',
          show: true
        }
      ],
      top: false
    }
  },
  methods: {
    tops() {
      var timer = setInterval(
        () =>
          document.documentElement.scrollTop <= 0
            ? clearInterval(timer)
            : window.scrollTo(0, document.documentElement.scrollTop - 10),
        17
      )
    }
  },
  mounted() {
    var THIS = this
    window.addEventListener('scroll', function() {
      var scrollTop =
        document.documentElement.scrollTop || document.body.scrollTop

      if (scrollTop >= 680) {
        THIS.top = true
      } else {
        THIS.top = false
      }
    })
  }
}
</script>
<style scoped>
.right {
  position: fixed;
  right: 0px;
  bottom: 50px;
  height: 120px;
  z-index: 500;
  background: white;
  width: 43px;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
}
.right_child {
  width: 38px;
  height: 40px;
  display: block;
  position: relative;
  text-align: center;
  padding-top: 13px;
}
.right_child i {
  font-size: 22px;
  color: #757575;
  padding-bottom: 6px;
}
.right_child i:hover {
  transition: opacity 0.3s;
  color: #ff6700;
}
.right_left {
  background: #fff;
  position: fixed;
  margin-top: -45px;
  right: 50px;
  z-index: 555;
  width: 80px;
  height: 40px;
  display: none;
  text-align: center;
  padding-top: 12px;
  border-radius: 5px;
}
.right_left p {
  color: #757575;
  font-size: 12px;
}

.right_child:hover + div {
  display: block;
}
.right_bottom:hover + div {
  display: block;
}
.right_bottom {
  float: right;
  width: 43px;
  height: 40px;
  position: fixed;
  bottom: 10px;
  right: 0px;
  z-index: 333;
  background: white;
  color: #757575;
  text-align: center;
  padding-top: 6px;
  padding-right: 6px;
}
.right_bottom i {
  font-size: 22px;
}
.right_bottom i:hover {
  transition: opacity 0.3s;
  color: #ff6700;
}
</style>
