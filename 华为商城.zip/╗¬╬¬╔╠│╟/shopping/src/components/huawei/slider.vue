<template>
  <div>
    <el-carousel height="550px" :interval="5000" arrow="always">
      <el-carousel-item v-for="(item, index) in mainBannerList" :key="index">
        <img :src="item" alt="" />
      </el-carousel-item>
    </el-carousel>
    <div class="ban">
      <img
        src="https://res8.vmallres.com/20200630/images/echannel/bg/bg-slide.png"
      />
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      mainBannerList: [
        'https://res.vmallres.com/pimages//pages/picImages/39663229269512236693.png',
        'https://res.vmallres.com/pimages//pages/picImages/89757980269518975798.jpg',
        'https://res.vmallres.com/pimages//pages/picImages/84407097369519070448.jpg',
        'https://res.vmallres.com/pimages//pages/picImages/81575097369519057518.jpg',
        'https://res.vmallres.com/pimages//pages/picImages/68012197369519121086.jpg',
        'https://res.vmallres.com/pimages//pages/picImages/89757980269518975798.jpg'
      ]
    }
  }
}
</script>
<style>
.ban {
  position: absolute;
  margin: 0 auto;
  width: 100%;
  height: 80px;
  margin-top: -80px;
  z-index: 2;
}
.ban img {
  width: 100%;
  height: 100%;
}
ul li:nth-of-type(5),
ul li:nth-of-type(10),
ul li:nth-of-type(11) {
  border: none !important;
}
.el-carousel__indicators--horizontal {
  bottom: 0;
  left: 87% !important;
  transform: translateX(-50%);
}
.el-carousel__indicators {
  position: absolute !important;
  bottom: 60px !important;
  left: 180px;
  z-index: 10 !important;
  width: 150px;
}

.el-carousel__button {
  width: 10px !important;
  height: 10px !important;
  float: left;
  border-radius: 50%;
  border: 1px solid #ffffff;
  margin: 0 3px;
}

.el-carousel__arrow--left {
  left: 25% !important;
  width: 60px !important;
  height: 60px !important;
  font-size: 20px !important;
}
.el-carousel__arrow--right {
  right: 5% !important;
  width: 60px !important;
  height: 60px !important;
  font-size: 20px !important;
}
.el-carousel__item img {
  width: 100%;
  height: 550px;
}
</style>
