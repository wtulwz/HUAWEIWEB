<template>
  <div>
    <div class="J_mod mod-productDrag mod-12">
      <div class="layout swiper-container swiper-container-horizontal">
        <ul class="drag-list swiper-wrapper clearfix">
          <li
            class="drag-items swiper-slide"
            v-for="(item, index) in arrayList"
            :key="index"
            :style="notice"
          >
            <a class="thumb">
              <p class="drag-img">
                <img :src="arrayList[index].src" />
              </p>
              <div class="drag-title">{{ item.title }}</div>
              <p class="drag-desc">{{ item.desc }}</p>
              <p class="drag-price">
                <span>{{ item.price }}</span>
              </p>
            </a>
          </li>
        </ul>
        <div
          class="drag-btn swiper-button-prev btn-prev"
          :class="{ 'swiper-button-disabled': isDisabled }"
          id="prev"
          @click="prevClick()"
        >
          <span></span>
        </div>
        <div
          class="drag-btn swiper-button-prev btn-next"
          :class="{ 'swiper-button-disabled': isDisabled1 }"
          id="next"
          @click="nextClick()"
        >
          <span></span>
        </div>
      </div>
    </div>
  </div> </template
>v
<script>
export default {
  name: 'Banner',
  data() {
    return {
      arrayList: [
        {
          id: 0,
          src:
            'https://res9.vmallres.com/pimages//product/6901443370825/428_428_3634DA1CBE520E38DDE86E5975FF6DCD9D9CFBB2F8C18EA5mp.png',
          title: 'HUAWEI P40 星钻保护壳',
          desc: '\u3000',
          price: '¥599'
        },
        {
          id: 1,
          src:
            'https://res9.vmallres.com/pimages//product/6901443366118/428_428_2FD4ED9350633493B1C45E6AF0C14F1A6606D57F4B965754mp.png',
          title: 'HUAWEI P40 Pro 硅胶保护壳',
          desc: '\u3000',
          price: '¥99'
        },
        {
          id: 2,
          src:
            'https://res9.vmallres.com/pimages//product/6901443365913/428_428_18CBD78F67E1DB71C5796A242BEA15136FE38C62872E1254mp.png',
          title: 'HUAWEI P40 皮革保护壳',
          desc: '\u3000',
          price: '¥99'
        },
        {
          id: 3,
          src:
            'https://res9.vmallres.com/pimages//product/6901443365883/428_428_F96EFB3382C7D8440E8B159F454373E7CB1D144EB24F0389mp.png',
          title: 'HUAWEI P40 智能视窗保护套',
          desc: '\u3000',
          price: '¥299'
        },
        {
          id: 4,
          src:
            'https://res9.vmallres.com/pimages//product/6901443344697/428_428_616DE7DA2AA39EE71B197C986CB09F7A6D2E7C357EF6E12Cmp.png',
          title: 'FreeBuds 3 无线耳机',
          desc: '半开放式主动降噪',
          price: '¥999'
        },
        {
          id: 5,
          src:
            'https://res0.vmallres.com/pimages//product/6901443369614/428_428_100700F1A17202378058B2EA2459E89F4EE6F17C06A133CCmp.png',
          title: '华为超级快充立式无线充电器',
          desc: '40W无线超级快充',
          price: '¥299'
        },
        {
          id: 6,
          src:
            'https://res7.vmallres.com/pimages//product/6901443288335/428_428_1553601252627mp.png',
          title: '华为40W超级快充移动电源',
          desc: '双向40W超级快充 多协议兼容',
          price: '¥329'
        },
        {
          id: 7,
          src:
            'https://res1.vmallres.com/pimages//product/6901443348213/428_428_49CE58ADB0BBD3D50078DB64A831141F6ABA2779A5D21027mp.png',
          title: '华为超级快充无线车充',
          desc: '27W大功率 智能开合感应',
          price: '¥299'
        },
        {
          id: 8,
          src:
            'https://res5.vmallres.com/pimages//product/6901443257386/428_428_1554811852693mp.png',
          title: '华为NM存储卡',
          desc: '海量存储随心用',
          price: '¥209'
        },
        {
          id: 9,
          src:
            'https://res9.vmallres.com/pimages//product/6901443256228/428_428_1553777061415mp.png',
          title: '华为充电器快充版',
          desc: '40W SuperCharge超级快充',
          price: '¥159'
        },
        {
          id: 10,
          src:
            'https://res9.vmallres.com/pimages//product/6901443364664/428_428_2F1424D03990990DAF9A8509A31D76239C281BFCAD1DD1FAmp.png',
          title: 'HUAWEI P40 无线充电保护壳（深海蓝）',
          desc: '\u3000',
          price: '¥299'
        }
      ],
      //当前显示图片索引
      currentIndex: 0,
      notice: 'right: 0px ',
      isDisabled: false,
      isDisabled1: false
    }
  },
  methods: {
    nextClick() {
      //当前索引等于图片张数-1时，到达最后一张图了，此时触发该事件
      //则应将currentIndex赋值为0，设为第一张
      if (this.currentIndex >= 0 && this.currentIndex <= 4) {
        this.isDisabled = false
        this.notice = 'right:' + 1200 + 'px'
        this.currentIndex = 5
      } else if (this.currentIndex >= 5 && this.currentIndex <= 9) {
        this.isDisabled = false
        this.notice = 'right:' + 1440 + 'px'
        this.currentIndex = 10
      } else {
        this.isDisabled1 = true
        this.isDisabled = false
      }
    },
    prevClick() {
      //当前索引等于0时，到达第一张图了，此时触发该事件
      //则应将currentIndex赋值为图片张数-1，设为最后一张
      if (this.currentIndex >= 0 && this.currentIndex <= 4) {
        this.isDisabled = true
        this.isDisabled1 = false
      } else if (this.currentIndex >= 5 && this.currentIndex <= 9) {
        //currentIndex-1
        this.isDisabled1 = false
        this.notice = 'right:' + 0 + 'px'
        this.currentIndex = 0
      } else {
        this.isDisabled1 = false
        this.notice = 'right:' + 1200 + 'px'
        this.currentIndex = 5
      }
    }
  }
}
</script>
<style scoped>
@import url(../../assets/p40/css/Banner.css);
@import url(../../assets/p40/css/header.css);
</style>
