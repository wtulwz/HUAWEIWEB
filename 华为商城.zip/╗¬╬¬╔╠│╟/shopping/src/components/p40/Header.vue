<template>
  <div>
    <div class="J_mod mod-topnav topnav-11">
      <div class="mod14-carnival-header-wrp">
        <img
          src="https://res6.vmallres.com/shopdc/pic/3005951e-c8da-4b33-8df1-3b83ae11b411.jpg"
        />
        <div class="mod14-carnival-header clearfix">
          <div>
            <div class="mod14-carnival-menu">
              <ul>
                <li v-for="(item, index) in topList" :key="index">
                  <a href="javascript:void(0)">{{ item.title }}</a>
                </li>
                <li>
                  <div class="unlogin">
                    <img :src="logoList.icon" alt />
                    <a>登录</a>
                    <p class="divid"><a>注册</a></p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="J_mod mod-pic pic-1">
      <div class="pic-wrap">
        <img :src="logoList.icon_1" alt="" />
      </div>
    </div>
    <div class="J_mod mod-coupons couponpic-16">
      <div class="mod22-carnival-coupons-wrp">
        <div class="mod22-carnival-coupons">
          <img :src="logoList.icon_2" alt="" />
        </div>
      </div>
    </div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.icon_3" alt="" />
      </div>
    </div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.icon_4" alt="" />
      </div>
    </div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.icon_5" alt="" />
      </div>
    </div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.icon_6" alt="" />
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Header',
  data() {
    return {
      topList: [
        {
          title: 'P40丨5G'
        },
        {
          title: 'P40 Pro丨5G'
        },
        {
          title: 'P40 Pro+丨5G'
        }
      ],
      logoList: {
        icon:
          'https://res7.vmallres.com/shopdc/pic/5c40865a-e1fb-443a-a7d3-981c4fcd92a9.png',
        icon_1:
          'https://res9.vmallres.com/shopdc/pic/68807131-09a1-40bc-b59e-98c896f532aa.jpg',
        icon_2:
          'https://res7.vmallres.com/shopdc/pic/1d09b73b-fde4-41c2-b84c-9ae8fc413e57.jpg',
        icon_3:
          'https://res9.vmallres.com/shopdc/pic/f17df110-19ab-465e-bfdc-6fa1fc283faf.jpg',
        icon_4:
          'https://res7.vmallres.com/shopdc/pic/ede00758-be83-4c84-8daf-a7ab15f606b8.jpg',
        icon_5:
          'https://res7.vmallres.com/shopdc/pic/7fc6d457-2461-4a1e-bfe8-c525e4b2c59f.jpg',
        icon_6:
          'https://res7.vmallres.com/shopdc/pic/78ac34e9-c886-4f11-ab3d-5e987121564d.jpg'
      }
    }
  }
}
</script>
<style scoped>
@import url(../../assets/p40/css/header.css);
</style>
