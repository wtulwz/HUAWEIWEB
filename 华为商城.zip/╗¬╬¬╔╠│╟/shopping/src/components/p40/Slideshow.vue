<template>
  <div>
    <div class="J_mod mod-pic">
      <div
        class="pic-wrap"
        id="banner"
        @mouseover="stopPlay()"
        @mouseleave="autoPlay()"
      >
        <a href="#">
          <img
            :src="imgs[currentIndex].src"
            class="banner-slide slide-active"
          />
        </a>
        <div class="dots" id="dots">
          <template v-for="(item, index) in imgs">
            <span
              :key="item.id"
              :class="{ active: currentIndex == index }"
              @click="goPage(index)"
              @mouseover="goPage(index)"
            ></span>
          </template>
        </div>
      </div>
    </div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.img_1" alt="" />
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Slideshow',
  data() {
    return {
      imgs: [
        {
          id: 0,
          src:
            'https://res0.vmallres.com/shopdc/pic/dfccd45c-88e8-481d-90da-d7bae408eae4.jpg'
        },
        {
          id: 1,
          src:
            'https://res4.vmallres.com/shopdc/pic/1ac1d0d6-29f3-4516-a693-698b4ad0ccb1.jpg'
        },
        {
          id: 2,
          src:
            'https://res0.vmallres.com/shopdc/pic/4a5af99a-902e-4957-b237-7596670b7a9f.jpg'
        }
      ],
      //当前菜单栏对应显示数据的id
      currentId: 0,
      //当前显示图片索引
      currentIndex: 0,
      //定时器
      timer: null,
      logoList: {
        img_1:
          'https://res3.vmallres.com/shopdc/pic/ab90a5ca-55c2-4a28-ab33-cbc3c161a259.jpg'
      }
    }
  },
  mounted() {
    this.autoPlay()
  },
  methods: {
    goPage(index) {
      this.currentIndex = index
    },
    nextClick() {
      //当前索引等于图片张数-1时，到达最后一张图了，此时触发该事件
      //则应将currentIndex赋值为0，设为第一张
      if (this.currentIndex == this.imgs.length - 1) {
        this.currentIndex = 0
      } else {
        //currentIndex+1
        this.currentIndex = this.currentIndex + 1
      }
    },
    prevClick() {
      //当前索引等于0时，到达第一张图了，此时触发该事件
      //则应将currentIndex赋值为图片张数-1，设为最后一张
      if (this.currentIndex == 0) {
        this.currentIndex = this.imgs.length - 1
      } else {
        //currentIndex-1
        this.currentIndex = this.currentIndex - 1
      }
    },
    autoPlay() {
      if (this.timer) clearInterval(this.timer)
      this.timer = setInterval(() => {
        this.nextClick()
      }, 3000)
    },
    stopPlay() {
      clearInterval(this.timer)
      // console.log(1);
    }
  }
}
</script>
<style scoped>
@import url(../../assets/p40/css/header.css);
@import url(../../assets/p40/css/Slideshow.css);
</style>
