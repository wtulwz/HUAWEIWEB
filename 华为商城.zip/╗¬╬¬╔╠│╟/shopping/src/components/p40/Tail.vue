<template>
  <div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.icon_2" alt />
      </div>
    </div>
    <div class="J_mod mod-pic">
      <div class="pic-wrap">
        <img :src="logoList.icon_3" alt />
      </div>
    </div>
    <div class="grid">
      <div class="layout">
        <ul class="grid-list clearfix">
          <li
            class="grid-items style-4"
            v-for="(item, index) in layoutList"
            :key="index"
          >
            <a href="javascript:void(0)">
              <p class="pic">
                <img :src="layoutList[index].src" />
              </p>
              <p class="title" title="">{{ item.title }}</p>
              <p class="desc" title="">{{ item.desc }}</p>
              <p class="sale">{{ item.sale }}</p>
              <div class="price-wrp">
                <p class="price">
                  <span class="price-currency">{{ item.currency }}</span>
                  <span class="price-amount">{{ item.amount }}</span>
                  <span class="price-form">{{ item.form }}</span>
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="grid">
      <div class="layout">
        <ul class="grid-list clearfix">
          <li
            class="grid-items style-4"
            v-for="(item, index) in layoutList1"
            :key="index"
          >
            <a href="javascript:void(0)">
              <p class="pic">
                <img :src="layoutList1[index].src" alt />
                {{ item.icon }}
              </p>
              <p class="title" :title="item.title">{{ item.title }}</p>
              <p class="desc" :title="item.desc">{{ item.desc }}</p>
              <p class="sale">{{ item.sale }}</p>
              <div class="price-wrp">
                <p class="price">
                  <span class="price-currency">{{ item.currency }}</span>
                  <span class="price-amount">{{ item.amount }}</span>
                  <span class="price-from">{{ item.form }}</span>
                </p>
              </div>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="J_mod mod-coupons couponpic-16">
      <div class="mod22-carnival-coupons-wrp">
        <div class="J_anchors">
          <a
            class="J_anchor anchor-hotList1"
            href="https://www.vmall.com/notice-10758"
            target="_blank"
          ></a>
          <a class="J_anchor anchor-hotList" href="#top"></a>
        </div>
        <div class="mod22-carnival-coupons">
          <img :src="logoList.icon_4" alt />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Tail',
  data() {
    return {
      logoList: {
        icon_2:
          'https://res4.vmallres.com/shopdc/pic/2a0468b3-a998-498e-8806-db9b6a48d09e.jpg',
        icon_3:
          'https://res7.vmallres.com/shopdc/pic/9d678266-518a-4dd7-8e90-670b11e03faa.jpg',
        icon_4:
          'https://res8.vmallres.com/shopdc/pic/ab56d4a0-5940-4824-ba9d-191ff24e8ce1.jpg'
      },
      layoutList: [
        {
          src:
            'https://res0.vmallres.com/shopdc/pic/f2ee3235-bbfb-4312-b01f-56310c97ef9a.jpg',
          title: '华为 Mate 20 5G',
          desc: '麒麟990 | 4000万超感光徕卡三摄',
          sale: '12期免息|赠精美配件',
          currency: '¥',
          amount: '4469',
          form: '起'
        },
        {
          src:
            'https://res0.vmallres.com/shopdc/pic/e1cffba8-4d51-4f11-9bdc-327bc4a8a632.png',
          title: 'MateBook X Pro',
          desc: '2020款丨3K触控全面屏',
          sale: '直降11元+赠鼠标+3期免息',
          currency: '¥',
          amount: '7988',
          form: '起'
        },
        {
          src:
            'https://res2.vmallres.com/shopdc/pic/adcb5e10-77f3-4f58-ae5d-57aedd344caa.jpg',
          title: 'WATCH GT 2 时尚款',
          desc: '时尚版颜色新上市 | 麒麟AI芯片',
          sale: '限时直降100元',
          currency: '¥',
          amount: '1488',
          form: '起'
        },
        {
          src:
            'https://res2.vmallres.com/shopdc/pic/fa2974cc-3205-4eb6-a34d-64de86064fa8.png',
          title: 'MatePad Pro',
          desc: '购麒麟990芯片丨多屏协同',
          sale: '限时直降100元',
          currency: '¥',
          amount: '3199',
          form: '起'
        }
      ],
      layoutList1: [
        {
          src:
            'https://res1.vmallres.com/shopdc/pic/19550c81-fac6-4193-ab06-9b4459d1ba0e.jpg',
          title: '华为智慧屏 V65i',
          desc: 'AI慧眼丨多方视频通话',
          sale: '预订最高省1000+12期免息',
          currency: '¥',
          amount: '5199'
        },
        {
          src:
            'https://res3.vmallres.com/shopdc/pic/4c34570f-a9e6-42d9-91ab-5f49618f076f.png',
          title: 'FreeBud 3有线充版',
          desc: '半开放式主动降噪',
          sale: '预订最高省200 享6期免息',
          currency: '¥',
          amount: '749'
        },
        {
          src:
            'https://res9.vmallres.com/shopdc/pic/f7bc7769-a74c-450f-bf0d-b6f2baea081b.png',
          title: '华为路由Q25',
          desc: '即插即用丨超级组网',
          sale: '限时直降20元',
          currency: '¥',
          amount: '479'
        },
        {
          src:
            'https://res6.vmallres.com/pimages//product/6901443399741/428_428_7813B1CCCF77D16DF12B34ABE1FFD5D03564F80A566DE67Cmp.png',
          title: '华为AI音箱',
          desc: '华为分享丨一碰传音',
          sale: '限时直降20元',
          currency: '¥',
          amount: '279',
          form: '起'
        }
      ]
    }
  }
}
</script>
<style scoped>
@import url(../../assets/p40/css/header.css);
@import url(../../assets/p40/css/Tail.css);
</style>
