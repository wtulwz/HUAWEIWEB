<template>
  <div>
    <div class="shortcut">
      <div class="layout">
        <div class="s-sub">
          <ul>
            <li
              :class="item.isDrop ? 's-dropdown' : ''"
              v-for="(item, index) in shortcutLeftList"
              :key="index"
            >
              {{ item.isDrop ? '' : item.title }}
              <div class="h" v-if="item.isDrop">
                <a href="javascript:void(0)" class="icon-dropdown">
                  {{ item.title_more }}
                </a>
              </div>
              <div class="b" v-if="item.isDrop">
                <div :class="item.isDrop ? 'content1' : ''">
                  <ul>
                    <li v-for="(title, index) in item.content" :key="index">
                      {{ title }}
                    </li>
                  </ul>
                </div>
                <div
                  :class="item.isIconDrop ? 'content2' : ''"
                  v-show="item.isIconDrop"
                ></div>
              </div>
            </li>
          </ul>
        </div>
        <div class="s-main">
          <ul>
            <li v-for="(item, index) in shortcutRightList" :key="index">
              <div :class="item.isDrop ? 's-dropdown' : ''">
                {{ item.isDrop ? '' : item.title }}
                <div class="h" v-if="item.isDrop">
                  <a href="javascript:void(0)" class="icon-dropdown">
                    {{ item.title_more }}
                  </a>
                </div>
                <div class="b" v-if="item.isDrop">
                  <div :class="item.isDrop ? 'content1' : ''">
                    <ul>
                      <li v-for="(title, index) in item.content" :key="index">
                        {{ title }}
                      </li>
                    </ul>
                  </div>
                  <div
                    :class="item.isIconDrop ? 'content2' : ''"
                    v-show="item.isIconDrop"
                  >
                    <div class="dropdown-navs-icon">
                      <a href="javascript:void(0)">
                        <span></span>
                        商城首页
                      </a>
                    </div>
                    <div class="page">
                      <div class="fl page-list">
                        <div
                          class="blod"
                          v-for="(title, index) in item.blod1"
                          :key="index"
                        >
                          {{ title }}
                        </div>
                        <div>
                          <div
                            class="fl"
                            v-for="(title, index) in item.page1"
                            :key="index"
                          >
                            <a href="javascript:void(0)">{{ title }}</a>
                          </div>
                        </div>
                      </div>
                      <div class="fl page-list">
                        <div
                          class="blod"
                          v-for="(title, index) in item.blod2"
                          :key="index"
                        >
                          {{ title }}
                        </div>
                        <div>
                          <div
                            class="fl"
                            v-for="(title, index) in item.page2"
                            :key="index"
                          >
                            <a href="javascript:void(0)">{{ title }}</a>
                          </div>
                        </div>
                      </div>
                      <div class="fl page-list">
                        <div
                          class="blod"
                          v-for="(title, index) in item.blod3"
                          :key="index"
                        >
                          {{ title }}
                        </div>
                        <div>
                          <div
                            class="fl"
                            v-for="(title, index) in item.page3"
                            :key="index"
                          >
                            <a href="javascript:void(0)">{{ title }}</a>
                          </div>
                        </div>
                      </div>
                      <div class="fl page-list">
                        <div
                          class="blod"
                          v-for="(title, index) in item.blod4"
                          :key="index"
                        >
                          {{ title }}
                        </div>
                        <div>
                          <div
                            class="fl"
                            v-for="(title, index) in item.page4"
                            :key="index"
                          >
                            <a href="javascript:void(0)">{{ title }}</a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div
                    :class="item.isCode ? 'content3' : ''"
                    v-show="item.isCode"
                  >
                    <div class="dropdown-code-detail">
                      <img class="code-img" :src="logoList.code_img" alt="" />
                      <div class="code-info">
                        <p class="title">华为商城app</p>
                        <p class="red">
                          新人享好礼
                          <br />最高5000积分
                        </p>
                        <span class="icon-andrid fl mgr-5"></span>
                        <span class="icon-ios fl mgr-5"></span>
                        <span class="icon-wechat fl"></span>
                      </div>
                    </div>
                    <div class="dropdown-code-detail">
                      <img class="code-img" :src="logoList.code_img2" alt="" />
                      <div class="code-info">
                        <p class="title">华为商城公众号</p>
                        <p class="page">微信扫一扫</p>
                        <span class="icon-wechat fl"></span>
                      </div>
                    </div>
                    <div class="dropdown-code-detail">
                      <img class="code-img" :src="logoList.code_img3" alt="" />
                      <div class="code-info">
                        <p class="title">华为商城小程序</p>
                        <span class="icon-wechat fl"></span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div
                :class="item.isIcon ? 's-dropdownIcon' : ''"
                v-if="item.isIcon"
              >
                <div class="h" v-if="item.isIcon">
                  <a href="javascript:void(0)" class="icon-dropdown">
                    {{ item.title_icon }}( )
                  </a>
                </div>
                <div class="b" v-if="item.isIcon">
                  <div
                    :class="item.isIcon ? 'content1' : ''"
                    v-show="item.isIcon"
                  >
                    <p class="cartIcon">
                      <span></span>
                    </p>
                    <p class="cartInfo">
                      {{ item.title_cart }}
                    </p>
                  </div>
                  <div
                    :class="item.isIconDrop ? 'content2' : ''"
                    v-show="item.isIconDrop"
                  ></div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="header">
      <div class="layout">
        <div class="left">
          <div class="logo">
            <img
              :src="logoList.logo_image"
              alt=""
              width="205px"
              height="36px"
            />
          </div>
          <div class="naver-class">
            <a href="javascript:void(0)" class="link">全部商品分类</a>
            <div class="category">
              <div class="b">
                <ul class="category-list">
                  <li
                    v-for="(item, index) in categoryList"
                    :key="index"
                    class="category-item"
                    v-on:mouseover="addClassload(index)"
                    v-on:mouseout="removeClassload(index)"
                    v-bind:class="{
                      active: active && index == current,
                      active1: item.active1
                    }"
                  >
                    <div class="category-item-bg">
                      <div class="category-info">
                        <a href="javascript:void(0)">
                          <span>{{ item.title }}</span>
                        </a>
                      </div>
                    </div>
                    <div
                      class="category-panels"
                      :class="item.class"
                      v-if="item.class === 'category-panels-1'"
                    >
                      <ul class="subcate-list clearfix">
                        <li
                          v-for="(item1, index) in item.subcateItem"
                          :key="index"
                          class="subcate-item"
                        >
                          <a href="javascript:void(0)">
                            <img :src="item1.img" alt />
                            <p>
                              <span>{{ item1.title }}</span>
                            </p>
                          </a>
                        </li>
                        <li class="subcate-btn">
                          <a href="javascript:void(0)">查看全部</a>
                        </li>
                      </ul>
                    </div>
                    <div
                      class="category-panels"
                      :class="item.class"
                      v-else-if="item.class === 'category-panels-2'"
                    >
                      <ul class="subcate-list clearfix">
                        <li
                          v-for="(item1, index) in item.subcateItem1"
                          :key="index"
                          class="subcate-item"
                        >
                          <a href="javascript:void(0)">
                            <img :src="item1.img" alt />
                            <p>
                              <span>{{ item1.title }}</span>
                            </p>
                          </a>
                        </li>
                      </ul>
                      <ul class="subcate-list clearfix">
                        <li
                          v-for="(item1, index) in item.subcateItem2"
                          :key="index"
                          class="subcate-item"
                        >
                          <a href="javascript:void(0)">
                            <img :src="item1.img" alt />
                            <p>
                              <span>{{ item1.title }}</span>
                            </p>
                          </a>
                        </li>
                        <li class="subcate-btn">
                          <a href="javascript:void(0)">查看全部</a>
                        </li>
                      </ul>
                    </div>
                    <div class="category-panels" :class="item.class" v-else>
                      <ul class="subcate-list clearfix">
                        <li
                          v-for="(item1, index) in item.subcateItem1"
                          :key="index"
                          class="subcate-item"
                        >
                          <a href="javascript:void(0)">
                            <img :src="item1.img" alt />
                            <p>
                              <span>{{ item1.title }}</span>
                            </p>
                          </a>
                        </li>
                      </ul>
                      <ul class="subcate-list clearfix">
                        <li
                          v-for="(item1, index) in item.subcateItem2"
                          :key="index"
                          class="subcate-item"
                        >
                          <a href="javascript:void(0)">
                            <img :src="item1.img" alt />
                            <p>
                              <span>{{ item1.title }}</span>
                            </p>
                          </a>
                        </li>
                      </ul>
                      <ul class="subcate-list clearfix">
                        <li
                          v-for="(item1, index) in item.subcateItem3"
                          :key="index"
                          class="subcate-item"
                        >
                          <a href="javascript:void(0)">
                            <img :src="item1.img" alt />
                            <p>
                              <span>{{ item1.title }}</span>
                            </p>
                          </a>
                        </li>
                        <li class="subcate-btn">
                          <a href="javascript:void(0)">查看全部</a>
                        </li>
                      </ul>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="naver">
            <ul>
              <li><img :src="logoList.icon_1" alt="" /></li>
              <li><img :src="logoList.icon_2" alt="" /></li>
              <li
                class="title"
                v-for="(item, index) in logoList.title"
                :key="index"
                style="font-size:16px;"
              >
                {{ item }}
              </li>
            </ul>
          </div>
        </div>
        <div class="right">
          <div class="search">
            <input type="text" />
            <span class="iconfont icon-search">&#xe614;</span>
            <div class="search-key">
              <p v-for="(item, index) in logoList.search_key" :key="index">
                {{ item }}
              </p>
            </div>
            <div class="search-history">
              <div class="search-history-list">
                <p
                  v-for="(item, index) in logoList.search_history"
                  :key="index"
                >
                  {{ item }}
                </p>
                <ul>
                  <li
                    class="title"
                    v-for="(item, index) in logoList.search_history_list"
                    :key="index"
                  >
                    {{ item }}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'Header',
  data() {
    return {
      shortcutLeftList: [
        {
          title: '首页'
        },
        {
          title: '华为官网'
        },
        {
          title: '荣耀官网'
        },
        {
          title: '花粉俱乐部'
        },
        {
          title: 'V码(优购码)'
        },
        {
          title: '企业购'
        },
        {
          title: 'Select Region'
        },

        {
          title_more: '更多精彩',
          isDrop: true,
          isIconDrop: false,
          content: ['EMUI', '应用市场', '华为终端云空间', '开发者联盟']
        }
      ],
      shortcutRightList: [
        {
          title: '请登录',
          isLink: true
        },
        {
          title: '注册',
          isLink: true
        },
        {
          title: '我的订单'
        },
        {
          title_more: '客户服务',
          isDrop: true,
          content1: true,
          content: ['服务中心', '联系客服']
        },
        {
          title_more: '网站导航',
          isDrop: true,
          content1: false,
          isIconDrop: true,
          blod1: ['频道'],
          page1: ['华为专区', '荣耀专区', '企业购'],
          blod2: ['产品'],
          page2: [
            '手机',
            '笔记本',
            '平板',
            '智能穿戴',
            '智能家居',
            '智慧屏',
            '耳机音箱',
            '热销配件',
            '生态产品',
            '增值服务'
          ],
          blod3: ['增值服务'],
          page3: ['以旧换新', '补购保障', '一口价换电池'],
          blod4: ['会员'],
          page4: ['会员频道']
        },
        {
          title_more: '手机版',
          isDrop: true,
          content1: false,
          isCode: true
        },
        {
          title_icon: '购物车',
          isDrop: false,
          isIcon: true,
          title_cart: '您的购物车是空的，赶紧选购吧~',
          cart: this.cart
        }
      ],
      logoList: {
        logo_image:
          'https://res.vmallres.com/pimages//common/config/logo/SXppnESYv4K11DBxDFc2.png',
        icon_1:
          'https://res.vmallres.com/pimages//navigation/icon/GrguiqzHENWVYHYWyHBM.png',
        icon_2:
          'https://res.vmallres.com/pimages//navigation/icon/AHwTUFRpDSQyuIZ7tLJz.png',
        code_img:
          'https://res.vmallres.com/pimages//pages/cdnImages/FWETOIrFlCrX4xuB8E16.png',
        code_img2:
          'https://res.vmallres.com/pimages/sale/2018-11/20181116180507506.jpg',
        code_img3:
          'https://res.vmallres.com/pimages//sale/2018-12/6Y7SW4v4hnJ9kl9fDC9d.jpg',
        title: ['华为P40系列', '荣耀30系列', '安心居家'],
        search_key: ['P40', '荣耀30'],
        search_history: ['历史记录'],
        search_history_list: [
          'P40',
          '荣耀V30',
          'nova7',
          '华为粉丝日',
          '荣耀X10',
          'nova 7 se',
          '荣耀30S',
          'P40 Pro',
          '荣耀30青春',
          'Mate 30'
        ]
      },
      categoryList: [
        {
          active1: true,
          title: '手机',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: 'HUAWEI P系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Dfv6Z1jNUpkSdQEfjU40.png'
            },
            {
              title: 'HUAWEI Mate系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/emEoURCoAws3bwrIgjI8.png'
            },
            {
              title: 'HUAWEI nova系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/JtWD6wvaxu0qmHbN2tbO.png'
            },
            {
              title: '华为畅享系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/wJHIfRVWj3kjLp9RoTBN.png'
            },
            {
              title: 'HUAWEI 麦芒系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/93515799859519751539.png'
            }
          ],
          subcateItem2: [
            {
              title: '荣耀 V系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/J0jm7RuLopoqLL6j9nWc.png'
            },
            {
              title: '荣耀 HONOR系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/BcIFunByzSBaydhI8X8T.png'
            },
            {
              title: '荣耀 Play系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/RekgcFmB36D9LlwLKmtt.png'
            },
            {
              title: '华为畅享系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/wJHIfRVWj3kjLp9RoTBN.png'
            }
          ]
        },
        {
          title: '笔记本',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: '华为MateBook X系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/RfnzRjvwIx1VTVm8xHfk.png'
            },
            {
              title: '华为MateBook系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/plqBwqiWNT7w3S1oHify.png'
            },
            {
              title: '华为MateBook D系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/tDI1s1C6u0UNK3kpjX35.png'
            },
            {
              title: '华为MateBook B系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/91536469069516463519.png'
            },
            {
              title: '荣耀MagicBook系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/w1o5IBLA7nNHhuMb2wTl.png'
            }
          ],
          subcateItem2: [
            {
              title: '荣耀MagicBook Pro系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/hTG8axcpAcm4rlc953p1.png'
            }
          ]
        },
        {
          title: '平板',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: '华为MatePad 系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/SoXonWnoeMUuz9KZRGyw.png'
            },
            {
              title: '荣耀 V系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/8wlL4vrACOekn5kexj47.jpg'
            },
            {
              title: '华为畅享 系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/xrtZtMAu7qwZRV7drG4A.png'
            },
            {
              title: '荣耀数字系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/LgNX0tnzWTb8Mu3xanaG.png'
            },
            {
              title: '荣耀畅玩系列',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/6bQtXCQDRZ8480l6N1Eo.png'
            }
          ]
        },
        {
          title: '智能穿戴&VR',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: '智能手表',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/bvJbZEMQTr1qy29qnvxZ.png'
            },
            {
              title: '儿童手表',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/sYl3EZsnaJp74kySK0uW.png'
            },
            {
              title: '智能手环',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Op9zTFnetpE2UBz72lZ6.png'
            },
            {
              title: 'VR',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/7rB1eW3yTzlmsJxUhz4o.png'
            },
            {
              title: '智能健康配件',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/svCuLCsIylj3EagzlFJm.png'
            }
          ]
        },
        {
          title: '智能家居',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: '智能路由',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/CSkYxTgopbtV6bLHOxWq.png'
            },
            {
              title: '移动路由',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/httvqlH4j44xjH2Fkoeb.png'
            },
            {
              title: '智能音箱',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/eXsJchzxTzKRTnevFe0r.png'
            },
            {
              title: '智能存储',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/G1jaM3KiE5xuF7x0YZ7g.png'
            },
            {
              title: 'HiLink生态',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/DJsv7p3cchO5rb1BawwY.png'
            }
          ]
        },
        {
          title: '智慧屏',
          class: 'category-panels-1',
          subcateItem: [
            {
              title: '华为智慧屏',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/jCygCJMv6ginekIsCBmu.png'
            },
            {
              title: '荣耀智慧屏',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Y9Qxdhyx2CQ6vFxPY89r.png'
            }
          ]
        },
        {
          title: '耳机音箱',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: '真无线耳机',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/uMozRHKrVE2rb5X95pGr.jpg'
            },
            {
              title: '有线耳机',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/8GZSNEOIyFTlKHGXJIUp.jpg'
            },
            {
              title: '蓝牙耳机',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Q4tB9qli0N2lI9aqbnUB.jpg'
            },
            {
              title: '蓝牙音箱',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/OArxm5z1VxtyOcsuNGWN.png'
            },
            {
              title: '智能眼镜',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/DeNI79kOsHbW8IXBE7Rh.png'
            }
          ],
          subcateItem2: [
            {
              title: '智能音箱',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/ponGt6tOncpW9tyJZhwC.png'
            }
          ]
        },
        {
          title: '配件',
          class: 'category-panels-3',
          subcateItem1: [
            {
              title: '充电器/线材',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/iXXgaQhk3RhRNcb3dUhX.png'
            },
            {
              title: '移动电源',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/jSg15QyIzY9GE4mVOHaI.jpg'
            },
            {
              title: '自拍杆/支架',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/UkPqRhFdsfuw0Mgon0lW.png'
            },
            {
              title: '摄像机/镜头',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/e7VsKW9NLDvxDXhBMFZD.png'
            },
            {
              title: '智能硬件',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/AGwf96xPj4cLuL3dpJ1G.png'
            }
          ],
          subcateItem2: [
            {
              title: '生活周边',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/B7R6qLbvn8J6DbwODyWS.png'
            },
            {
              title: '保护壳',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/RyT80PAF3dD0VUy9XTgz.png'
            },
            {
              title: '保护套',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/nxlajbLtHHaH00OhSaAv.png'
            },
            {
              title: '贴膜',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/UWVgAL2WFNeoVHZRRE8s.png'
            },
            {
              title: '个人电脑配件',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Xqw5avmFrpr7LGyNTZE0.png'
            }
          ],
          subcateItem3: [
            {
              title: '平板配件',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/4PoI3AWlpGikrJtR0gfY.png'
            },
            {
              title: '智慧屏配件',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/oYGaqUtNyOAa8gj1a3Pc.png'
            },
            {
              title: '穿戴配件',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/ecDhrcKmmX2lMEJ6EWUN.png'
            }
          ]
        },
        {
          title: '生态产品',
          class: 'category-panels-3',
          subcateItem1: [
            {
              title: '智能灯光',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/0fiZED1M3bzCZCtrmVuv.png'
            },
            {
              title: '生活电器',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/iR28UGaUlGGtocEkV5vg.png'
            },
            {
              title: '数码周边',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/CjXb7nAKCcLrhloNO14u.png'
            },
            {
              title: '环境卫士',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Hbh7GYts0Ye1ozqXQsqC.png'
            },
            {
              title: '安防门锁',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/U8DruLnlMn8Mn4l8ankk.png'
            }
          ],
          subcateItem2: [
            {
              title: '健康保健',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/RJO1wsBU6rsbJeXf0kAl.png'
            },
            {
              title: '运动健身',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/gGcXeKvu6bIKZUwMJhuK.png'
            },
            {
              title: '户外出行',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/5Rf9Nz2tA6T0Hl7LQVGn.png'
            },
            {
              title: '厨电卫浴',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/Su3PP0R5phG77pi2PjHs.png'
            },
            {
              title: '影音娱乐',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/pAQE9qGrvT2kYOGERdmr.png'
            }
          ],
          subcateItem3: [
            {
              title: '个护美妆',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/isXiE0yeEU46E2DolmYs.png'
            }
          ]
        },
        {
          title: '增值服务&其他',
          class: 'category-panels-2',
          subcateItem1: [
            {
              title: '华为视频卡',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/ZQnJL2WVUmZvVDkFIDRE.png'
            },
            {
              title: '花币卡',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/druWEKy6zCanbd02FQhl.png'
            },
            {
              title: '华为音乐卡',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/qTEFwRvC8TEQ6qyHvIoB.png'
            },
            {
              title: '华为云空间',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/ppk5HSXix5wsEv4KY0KQ.png'
            },
            {
              title: '电池更换服务',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/8J0Q5RpbK23FoBD4nX2h.png'
            }
          ],
          subcateItem2: [
            {
              title: '服务器',
              img:
                'https://res.vmallres.com/pimages//pages/navigation/alMghfvLjM8qE4wuTjY4.png'
            },
            {
              title: 'AI 计算平台',
              img:
                'https://res.vmallres.com/pimages//pages/frontCategory/9xgKp8DlHGYOJTcuc4Qx.png'
            }
          ]
        }
      ]
    }
  },
  computed: {
    //计算属性
  },
  methods: {
    addClassload(index) {
      this.active = true
      this.current = index
      if (this.current !== 0) {
        this.categoryList[0].active1 = false
      }
    },
    removeClassload(index) {
      this.active = false
      this.current = index
      this.categoryList[0].active1 = true
    }
  }
}
</script>
<style scoped>
.shortcut {
  width: 100%;
  height: 36px;
  background-color: #2e2828;
}
.shortcut ul > li {
  height: 36px;
  color: #afafaf;
  font-size: 12px !important;
  float: left;
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 0 8px;
  position: relative;
}
.shortcut ul > li:first-child {
  padding-left: 0;
}
.shortcut ul > li:not(:first-child):before {
  content: '';
  width: 1px;
  height: 10px;
  background-color: #414141;
  position: absolute;
  top: 14px;
  left: 0;
}
.shortcut ul > li.s-dropdown::before {
  left: 10px;
}
.shortcut .b .content1 ul > li::before {
  display: none;
}
.shortcut .s-dropdown {
  position: relative;
  z-index: 310;
  margin: 0 -9px;
  height: 36px;
}
.shortcut .s-dropdown .h {
  position: relative;
  padding: 0 12px 0 10px;
  height: 36px;
}
.shortcut .s-dropdownIcon .h {
  padding-left: 23px;
}
.shortcut .s-dropdown .h a,
.shortcut .s-dropdownIcon .h a {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 36px;
  color: #afafaf;
  position: relative;
  padding-right: 15px;
}
.shortcut .s-dropdown .h a::before {
  content: '';
  width: 14px;
  height: 14px;
  background-image: url(https://res8.vmallres.com/20200630/images/echannel/icon/icon-common.svg);
  background-position: -71px 0;
  position: absolute;
  top: 12px;
  right: 0;
}
.shortcut .s-dropdown:hover .h {
  background-color: #ffffff;
}
.shortcut .s-dropdown:hover .h a {
  color: #cb242b;
  position: relative;
}
.shortcut .s-dropdown:hover .h a::before {
  background-position: -85px 0;
}
.shortcut .s-dropdown:hover .h {
  position: relative;
  z-index: 33;
}

.shortcut .s-dropdown .b {
  display: none;
  position: absolute;
  top: 36px;
  right: 8px;
  border-radius: 8px 0 8px 8px;
  box-shadow: 0 2px 36px 0 rgba(0, 0, 0, 0.07);
  background-color: #ffffff;
  float: left;
}
.shortcut .s-dropdown:hover {
  box-shadow: 0 2px 36px 0 rgba(0, 0, 0, 0.07);
}
.shortcut .s-dropdown .b .content1 {
  width: 119px;
  display: flex;
  padding: 6px 0 12px 0;
}
.shortcut .s-main .s-dropdown .b {
  display: none;
  position: absolute;
  float: left;
  top: 36px;
  right: 0px;
  border-radius: 8px 0 8px 8px;
  box-shadow: 0 2px 36px 0 rgba(0, 0, 0, 0.07);
  background-color: #ffffff;
}
.shortcut .s-main .s-dropdown .b .content1 {
  width: 85px;
  display: flex;
  padding: 6px 0 12px 0;
}
.shortcut .s-dropdown .b .content1 ul {
  width: 100%;
  /* height: 128px; */
  border-radius: 0 0 8px 8px;
}
.shortcut .s-dropdown .b .content1 ul > li {
  width: 100%;
  height: 32px;
  text-align: center;
  color: #414141;
  padding: 0;
}
.shortcut .s-dropdown .b .content1 ul > li:hover {
  color: #cb242b;
}
.shortcut .s-dropdown:hover .b {
  display: block;
}
.shortcut .s-dropdown .content2 {
  width: 893px;
  display: flex;
  line-height: 20px;
}
.shortcut .s-dropdown .content2 .dropdown-navs-icon {
  float: left;
  width: 50px;
  text-align: center;
  margin: 37px 46px 0 49px;
  color: #777;
}
.shortcut .s-dropdown .content2 .dropdown-navs-icon a:hover {
  color: #cb242b;
}
.shortcut .s-dropdown .content2 .dropdown-navs-icon a {
  color: #777;
}
.shortcut .s-dropdown .content2 .dropdown-navs-icon span {
  width: 50px;
  height: 50px;
  display: block;
  margin-bottom: 3px;
}
.shortcut .s-dropdown .content2 .dropdown-navs-icon span:before {
  content: '';
  display: block;
  width: 50px;
  height: 50px;
  background-image: url(https://res8.vmallres.com/20200630/images/echannel/icon/icon-common.svg);
  background-repeat: no-repeat;
  background-position: -202px 0;
}
.shortcut .s-dropdown .content2 .page .page-list {
  width: 185px;
  margin-top: 22px;
  margin-bottom: 20px;
  float: left;
}
.shortcut .s-dropdown .content2 .page .blod {
  font-size: 16px;
  font-weight: 700;
  color: #333333;
  margin-bottom: 8px;
}
.shortcut .s-dropdown .content2 .page a {
  float: left;
  color: #777777;
  width: 80px;
  overflow: hidden;
  margin-bottom: 4px;
}
.shortcut .s-dropdown .content2 .page a:hover {
  color: #cb242b;
}
.shortcut .s-dropdown .b .content3 {
  width: 244px;
  padding-bottom: 20px;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail {
  width: 303px;
  height: 99px;
  padding-bottom: 20px;
  border-bottom: 1px solid #e5e5e5;
  margin-bottom: 20px;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail:last-child {
  padding-bottom: 0;
  border-bottom: 0;
  margin-bottom: 0;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .code-img {
  margin-left: 14px;
  width: 99px;
  height: 99px;
  float: left;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .code-info {
  width: 180px;
  height: 99px;
  float: right;
  margin-left: 10px;
  line-height: 20px;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .code-info .title {
  font-size: 14px;
  font-weight: bold;
  margin-bottom: 5px;
  color: #3a3a3a;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .red {
  color: #cb242b;
  line-height: 16px;
  font-weight: 200px;
  margin-bottom: 5px;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .page {
  color: #777;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .code-info span {
  width: 32px;
  height: 32px;
  display: block;
  margin-top: 5px;
  float: left;
}
.shortcut .s-dropdown .b .content3 .dropdown-code-detail .code-info .mgr-5 {
  margin-right: 5px;
}
.shortcut
  .s-dropdown
  .b
  .content3
  .dropdown-code-detail
  .code-info
  span::before {
  content: '';
  display: block;
  width: 30px;
  height: 30px;
  margin-top: 1px;
  background-image: url(https://res8.vmallres.com/20200630/css/../images/echannel/icon/icon-common.svg);
  background-repeat: no-repeat;
}
.shortcut
  .s-dropdown
  .b
  .content3
  .dropdown-code-detail
  .code-info
  span.andrid::before {
  background-position: 0 0;
}
.shortcut
  .s-dropdown
  .b
  .content3
  .dropdown-code-detail
  .code-info
  span.icon-ios::before {
  background-position: -38px -113px;
}
.shortcut
  .s-dropdown
  .b
  .content3
  .dropdown-code-detail
  .code-info
  span.icon-wechat::before {
  background-position: -32px 0;
}

.shortcut .s-main {
  float: right;
}
.shortcut .s-dropdownIcon {
  margin: 0 -9px;
  background-color: #424242;
}
.shortcut .s-dropdownIcon .h a {
  position: relative;
  padding-left: 15px;
}
.shortcut .s-dropdownIcon .h a::before {
  content: '';
  width: 14px;
  height: 14px;
  position: absolute;
  top: 12px;
  left: -10px;
  background-image: url(https://res8.vmallres.com/20200630/images/echannel/icon/icon-common.svg);
  background-position: -103px -4px;
}
.shortcut .s-dropdownIcon:hover .h {
  background-color: #ffffff;
  position: relative;
}
.shortcut .s-dropdownIcon:hover .h a {
  color: #cb242b;
}
.shortcut .s-dropdownIcon:hover .h a::before {
  background-position: -123px -4px;
}
.shortcut .s-dropdownIcon .b {
  /* display: none; */
  position: absolute;
  top: 36px;
  right: 8px;
  border-radius: 8px 0 8px 8px;
  box-shadow: 0 2px 36px 0 rgba(0, 0, 0, 0.07);
  background-color: #ffffff;
}
.shortcut .s-dropdownIcon .b {
  display: none;
  box-shadow: 0 2px 36px 0 rgba(0, 0, 0, 0.07);
  position: absolute;
  top: 36px;
  right: 0px;
  background-color: #ffffff;
}
.shortcut .s-dropdownIcon .b .content1 {
  width: 460px;
  height: 250px;
  padding: 50px 0;
  background-color: white;
}
.shortcut .s-dropdownIcon .b .content1 p.cartIcon span {
  display: block;
  width: 100px;
  height: 100px;
  margin: 0 auto 10px;
  background-image: url(https://res8.vmallres.com/20200630/css/../images/echannel/icon/icon-common.svg);
  background-repeat: no-repeat;
  background-position: -262px 0;
}
.shortcut .s-dropdownIcon .b .content1 p.cartInfo {
  margin: 0 auto;
  text-align: center;
  color: #afafaf;
  line-height: 1;
  font-size: 14px;
}
.shortcut .s-dropdownIcon:hover .b {
  display: block;
  border-radius: 8px 0 8px 8px;
  z-index: 100;
}
.shortcut ul > li:hover {
  color: #ffffff;
  cursor: pointer;
}

.header {
  padding: 18px 0 15px 0;
  box-shadow: 0 0 46px rgba(0, 0, 0, 0.03);
}
.header .layout {
  height: 41px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
}
.header .layout .left {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header .layout .left .naver-class {
  float: left;
  height: 72px;
  margin-left: -70px;
  width: 223px;
}
.header .layout .left .naver-class a.link {
  font-size: 16px;
  margin-right: 24px;
  line-height: 40px;
  height: 56px;
  padding-left: 33px;
  position: relative;
  left: 69px;
  top: 17px;
  color: #3a3a3a;
}
.header .layout .left .naver-class:hover a.link {
  color: #ca141d;
}
.header .layout .left .naver-class a.link::before {
  content: '';
  width: 24px;
  height: 24px;
  display: block;
  background: url(https://res8.vmallres.com/20200630/images/echannel/icon/icon-category.png);
  background-repeat: no-repeat;
  background-position: 0 -25px;
  background-size: 100% 200%;
  position: absolute;
  top: -2px;
  left: 0;
}
.header .layout .left .naver-class:hover a.link::before {
  background-position: 0 -1px;
}

.naver-class:hover .category {
  display: block;
}
.naver-class .category {
  position: absolute;
  left: 7px;
  z-index: 1000;
  top: 56px;
  display: none;
}
.category {
  position: absolute;
  left: 0;
  top: 18px;
  width: 200px;
}
.naver-class .category .category-list {
  background: #fff;
}
.category .category-list {
  position: relative;
  height: 440px;
  box-shadow: 0 0 28px rgba(0, 0, 0, 0.08);
  background: rgba(255, 255, 255, 0.95);
  border-radius: 10px 0 0 10px;
  display: table;
  cursor: pointer;
}
.category .category-list:hover {
  border-radius: 10px 0 0 10px;
}
.category .category-item {
  display: table-row;
}
.category .category-item.active1:first-child .category-item-bg {
  border-radius: 10px 0 0 0;
  background-color: white;
  box-shadow: 0 0 28px rgba(0, 0, 0, 0.08);
}
.category .category-item.active1:last-child .category-item-bg {
  border-radius: 0 0 0 10px;
}
.category .category-item.active .category-item-bg {
  background: #fff;
  box-shadow: 0 0 28px rgba(0, 0, 0, 0.08);
  position: relative;
  overflow: hidden;
}
.category .category-item.active:last-child .category-item-bg {
  border-radius: 0 0 0 10px;
}
.category .category-item .category-item-bg {
  display: table-cell;
  vertical-align: middle;
}
.category .category-item.active1:first .category-item-bg:after {
  content: '';
  width: 60px;
  height: 75px;
  background: #fff;
  position: absolute;
  top: 0;
  right: -10px;
  z-index: 2;
  display: block;
}
.category .category-item.active .category-item-bg:after {
  content: '';
  width: 60px;
  height: 75px;
  background: #fff;
  position: absolute;
  top: 0;
  right: -10px;
  z-index: 2;
  display: block;
}
.category .category-info {
  padding-left: 16px;
  width: 184px;
  position: relative;
  cursor: pointer;
}
.category .category-info:after {
  content: '';
  width: 16px;
  height: 16px;
  background: url('https://res8.vmallres.com/20200630/images/echannel/icon/icon01.svg')
    no-repeat;
  background-position: -363px 0;
  position: absolute;
  top: 50%;
  right: 15px;
  z-index: 3;
  margin-top: -8px;
}
.category .category-info a {
  font-size: 16px;
  color: #848484;
}
.category .category-item.active1 .category-info a:hover {
  color: #ca141d;
}
.category .category-item.active .category-info a:hover {
  color: #ca141d;
}
.category .category-item .category-panels {
  position: absolute;
  left: 184px;
  top: 0px;
  height: 440px;
  background-color: white;
  padding: 20px 0 0 32px;
  border-radius: 0 10px 10px 0;
  box-shadow: 0 0 46px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  display: none;
  z-index: 1;
}
.category .category-item.active1 .category-panels {
  display: block;
}
.category .category-item:hover .category-panels {
  display: block;
}
.category .category-panels.category-panels-1 {
  width: 242px;
}
.category .category-panels.category-panels-2 {
  width: 484px;
}
.category .category-panels.category-panels-3 {
  width: 726px;
}
.category .subcate-list {
  width: 242px;
  margin: 0;
  float: left;
}
.category .subcate-list {
  width: 242px;
  margin: 0;
  float: left;
}
.category .subcate-list .subcate-item {
  float: left;
  margin-bottom: 25px;
}
.category .subcate-list .subcate-item a {
  display: table-cell;
  width: 230px;
  height: 60px;
  font-size: 14px;
  border-radius: 10px;
  margin-right: 0;
  vertical-align: middle;
}
.category .subcate-list .subcate-item a:hover {
  background: #f6f6f6;
}
.category .subcate-list .subcate-item a img {
  width: 48px;
  height: 48px;
  float: left;
  margin: 0 8px 0 12px;
}
.category .subcate-list .subcate-item a p {
  display: table-cell;
  height: 34px;
  line-height: 17px;
  position: relative;
  top: 7px;
  vertical-align: middle;
  color: #666;
  font-size: 14px;
  width: 150px;
  overflow: hidden;
}
.category .subcate-list .subcate-item a p span {
  max-height: 34px;
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.category .subcate-list .subcate-btn {
  float: left;
}
.category .subcate-list .subcate-btn a {
  width: 112px;
  height: 42px;
  line-height: 42px;
  margin-top: 8px;
  margin-left: 36px;
  border: 1px solid #f2f2f2;
  border-radius: 0 22px 22px 0;
  font-size: 13px;
  color: #999;
  display: block;
  position: relative;
  text-indent: 34px;
}
.category .subcate-list .subcate-btn a:before {
  content: '';
  width: 42px;
  height: 42px;
  background: #fff;
  border: 1px solid #f2f2f2;
  display: block;
  border-radius: 22px;
  position: absolute;
  top: -1px;
  left: -22px;
}
.category .subcate-list .subcate-btn a:after {
  content: '';
  width: 0;
  height: 0;
  display: block;
  border-bottom: 5px solid transparent;
  border-top: 5px solid transparent;
  border-left: 5px solid #c0c0c0;
  position: absolute;
  top: 16px;
  left: -1px;
}

.header .layout .left .naver {
  margin-top: -11px;
}
.header .layout .left .naver ul {
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.header .layout .left .naver ul > li > img {
  width: 74px;
  height: 24px;
  cursor: pointer;
}
.header .layout .left .naver ul > li > img:hover {
  opacity: 0.8;
}
.header .layout .logo {
  width: 205px;
  height: 41px;
  margin-right: 34px;
  position: relative;
  z-index: 1;
  cursor: pointer;
}
.header .naver {
  width: 516px;
  height: 40px;
}
.header .naver .title:hover {
  cursor: pointer;
  color: #cb242b;
}
.header .right .search {
  position: relative;
}
.header .right .search input {
  width: 240px;
  height: 28px;
  border-radius: 36px;
  border: 1px solid #f0f0f0;
  background-color: #f0f0f0;
  text-indent: 1.4em;
}
.header .right .search input:hover {
  border: 1px solid #c9c9c9;
}
.header .right .search .icon-search {
  font-size: 16px;
  font-weight: 400;
  position: absolute;
  top: 7px;
  right: 14px;
  color: #353535;
}
.header .right .search:hover .icon-search {
  color: #999999;
  cursor: pointer;
}
.header .right .search .search-key {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  position: absolute;
  top: 7px;
  right: 40px;
  font-size: 12px;
  color: #999999;
}
.header .right .search .search-key p:hover {
  color: #333333;
  cursor: pointer;
}
.header .right .search .search-key p:last-child {
  margin-left: 10px;
}
.header .right .search input:focus ~ .search-key {
  display: none;
}
.header .right .search .search-history {
  display: none;
  background-color: #ffffff;
  width: 240px;
  border-radius: 8px;
  position: absolute;
  top: 40px;
  line-height: 26px;
  font-size: 12px;
  z-index: 306;
  box-shadow: 0 2px 36px 0 rgba(0, 0, 0, 0.07);
}
.header .right .search .search-history .search-history-list {
  display: block;
  border-top: 1px solid #f2f2f5;
}
.header .right .search .search-history .search-history-list p {
  text-indent: 15px;
  height: 30px;
  line-height: 30px;
  font-size: 13px;
  color: #888;
}
.header .right .search .search-history .search-history-list ul {
  text-indent: 15px;
}
.header .right .search .search-history .search-history-list ul > li {
  padding-right: 17px;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: 12px;
  overflow: hidden;
  color: #333333;
  height: 30px;
  line-height: 30px;
  cursor: pointer;
}
.header .right .search .search-history .search-history-list ul > li:hover {
  background-color: #f0f0f0;
}
.header .right .search input:focus ~ .search-history {
  display: block;
}
@import url(../../assets/serve/css/iconfont.css);
</style>
