<template>
  <div>
    <div class="hot-board">
      <Slider></Slider>
    </div>
    <div class="help-serch-entrance">
      <p class="clearfix">
        <input type="text" :placeholder="search.help" />
        <a v-for="(item, index) in search.title" :key="index">{{ item }}</a>
      </p>
    </div>
    <div class="help-menu">
      <div class="h">
        <div class="layout" v-for="(item, index) in titles.title1" :key="index">
          {{ item }}
        </div>
      </div>
      <div class="layout">
        <ul class="help-menu-list clearfix">
          <li v-for="(item, index) in navlist" :key="index">
            <a href="javascript:void(0)">
              <img :src="item.img" alt="" />
              <span>{{ item.title }}</span>
            </a>
          </li>
        </ul>
      </div>
    </div>
    <div class="help-banner-small layout">
      <a href="javascript:void(0)">
        <img :src="imglist.img1" alt="" />
      </a>
    </div>
    <div class="helpclass-area layout">
      <ul class="clearfix">
        <li v-for="(item, index) in helpclasslist" :key="index">
          <img :src="item.img" alt="" />
          <div class="helpclass-info">
            <div class="helpclass-title">{{ item.title }}</div>
            <p>
              <a
                href="javascript:void(0)"
                v-for="(title, index) in item.content"
                :key="index"
                >{{ title }}</a
              >
            </p>
          </div>
        </li>
      </ul>
    </div>
    <div class="help-container">
      <div class="layout">
        <div
          class="help-title"
          v-for="(item, index) in titles.title2"
          :key="index"
        >
          {{ item }}
        </div>
        <div class="help-product">
          <div class="product-banner">
            <a href="javascript:void(0)">
              <img :src="imglist.img2" alt="" />
            </a>
          </div>
          <div class="product-area">
            <ul class="product-area-list clearfix">
              <li v-for="(item, index) in productarealist" :key="index">
                <div class="product-area-detail">
                  <img :src="item.img" alt="" />
                  <span class="product-area-title">{{ item.title }}</span>
                  <div class="product-area-info">
                    <dl>
                      <dt>
                        <span>{{ item.title }}</span>
                        <a href="javascript:void(0)">{{ item.more }}</a>
                      </dt>
                      <dd>
                        <a href="javascript:void(0)">{{ item.a1 }}</a>
                      </dd>
                      <dd>
                        <a href="javascript:void(0)">{{ item.a2 }}</a>
                      </dd>
                      <dd>
                        <a href="javascript:void(0)">{{ item.a3 }}</a>
                      </dd>
                      <dd>
                        <a href="javascript:void(0)">{{ item.a4 }}</a>
                      </dd>
                      <dd>
                        <a href="javascript:void(0)">{{ item.a5 }}</a>
                      </dd>
                      <dd>
                        <a href="javascript:void(0)">{{ item.a6 }}</a>
                      </dd>
                    </dl>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="help-area">
          <div class="contact-area">
            <div
              class="help-title"
              v-for="(item, index) in titles.title3"
              :key="index"
            >
              {{ item }}
            </div>
            <div class="help-contact clearfix">
              <div class="contact-btn">
                <ul>
                  <li class="contact-customer">
                    <div class="contact-title">
                      <span
                        v-for="(item, index) in customerlist.span"
                        :key="index"
                        >{{ item }}</span
                      >
                      <a
                        href="javascript:void(0)"
                        v-for="(item, index) in customerlist.a"
                        :key="index"
                        >{{ item }}</a
                      >
                    </div>
                    <p v-for="(item, index) in customerlist.p" :key="index">
                      {{ item }}
                    </p>
                  </li>
                  <li class="contact-phone">
                    <div class="contact-title">
                      <span
                        v-for="(item, index) in phonelist.span"
                        :key="index"
                      >
                        {{ item }}
                        <strong>
                          <span
                            style="color:#F79646;font-size:14px;"
                            v-for="(item, index) in phonelist.number"
                            :key="index"
                            >{{ item }}</span
                          >
                        </strong>
                      </span>
                    </div>
                    <p v-for="(item, index) in phonelist.p" :key="index">
                      {{ item }}
                    </p>
                  </li>
                  <li class="contact-suggestion">
                    <div class="contact-title">
                      <span
                        v-for="(item, index) in suggestionlist.span"
                        :key="index"
                        >{{ item }}</span
                      >
                      <a
                        href="javascript:void(0)"
                        v-for="(item, index) in suggestionlist.a"
                        :key="index"
                        >{{ item }}</a
                      >
                    </div>
                    <p v-for="(item, index) in suggestionlist.p" :key="index">
                      {{ item }}
                    </p>
                  </li>
                </ul>
              </div>
              <div class="contact-code">
                <ul>
                  <li class="contact-wechat">
                    <img
                      src="https://res.vmallres.com/pimages//sale/2018-09/20180906165955733.png"
                      alt=""
                    />
                    <span>华为商城官方微信</span>
                  </li>
                  <li class="contact-weibo">
                    <img
                      src="https://res.vmallres.com/pimages//sale/2018-09/20180906165954235.png"
                      alt=""
                    />
                    <span>华为商城官方微博</span>
                  </li>
                  <li class="contact-app">
                    <img
                      src="https://res.vmallres.com/pimages//sale/2018-09/20180906165952739.png"
                      alt=""
                    />
                    <span>华为会员服务APP</span>
                  </li>
                </ul>
                <div class="tips">
                  获取新品资讯，定时福利发放，商品优惠信息......
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="layout">
        <div
          class="help-title"
          v-for="(item, index) in titles.title4"
          :key="index"
        >
          {{ item }}
        </div>
      </div>
      <div class="help-banner">
        <a href="javascript:void(0)">
          <img :src="imglist.img3" alt="" />
        </a>
        <a href="javascript:void(0)">
          <img :src="imglist.img4" alt="" />
        </a>
        <a href="javascript:void(0)">
          <img :src="imglist.img5" alt="" />
        </a>
      </div>
    </div>
  </div>
</template>
<script>
import Slider from '@/components/serve/Slider.vue'
export default {
  name: '',
  data() {
    return {
      search: {
        help: ['请用一句话描述您的问题，如：“如何查找订单”'],
        title: ['提问']
      },
      titles: {
        title1: ['自助服务'],
        title2: ['产品支持'],
        title3: ['联系客服'],
        title4: ['华为商城官方服务']
      },
      imglist: {
        img1:
          'https://res.vmallres.com/pimages//template/content/2018/Vp2iJrv21fdtkEN2H91w.png',
        img2:
          'https://res.vmallres.com/pimages//pages/templateContent/s1QNXd2WXxrZNV8krPLS.jpg',
        img3:
          'https://res.vmallres.com/pimages//pages/ads/content/fNgsYHW3rqWD4ZIu4fza.png',
        img4:
          'https://res.vmallres.com/pimages//pages/ads/content/taIXyRSWwgZLaQ2qStIL.png',
        img5:
          'https://res.vmallres.com/pimages//pages/ads/content/G2xBTaFuQSOvOpwJb79y.png'
      },
      navlist: [
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/mQf94VZLEoAloHfgiizY.png',
          title: '订单/物流'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/HvdrRpvuBuywOYD7tWnD.png',
          title: '退换货'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/SN4Sh4Mdrz9f2cAiKTDJ.png',
          title: '价保'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/aNmh00UGl21T0cyCiSkl.png',
          title: '催单'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/ACEbzvnKQBJm96KL9E7L.png',
          title: '领券'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/DJK9VSD2HC2ENsWOxOoZ.png',
          title: '帐号中心'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/BmKPeS8bcLM5aiAJF4FX.png',
          title: '收货地址'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/heRhbXOlWO85vbjUrvkU.png',
          title: '以旧换新'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/8rSGJzdm7Pztqcx0o7sL.png',
          title: '补购保障'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/I14Pr9QogRsW87sNOf2O.png',
          title: '一口价换电池'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/ad4QfP7crhZUnozgYCQP.png',
          title: '服务店'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/EAcCPWM8pZXal187Fjp9.png',
          title: '保修政策'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/fNYHJqj6UsUkJd3Kodhj.png',
          title: '预约服务'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/xK0jLAHPykZ5s2WyYTAE.png',
          title: '寄修服务'
        },
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/7J4wuPrrmUknvdsw4qEM.png',
          title: '真伪鉴别'
        }
      ],
      helpclasslist: [
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1541492667122.png',
          title: '购物指南',
          content: [
            '订单操作',
            '支付帮助',
            '免息分期',
            '物流帮助',
            '以旧换新',
            '实用保险',
            '企业购',
            'O2O',
            '防伪查询'
          ]
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1541492657623.png',
          title: '帐户管理',
          content: [
            '帐号注册',
            '修改密码',
            '找回密码',
            '实名认证',
            '服务协议',
            '隐私声明',
            'COOKIES'
          ]
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1541492627841.png',
          title: '权益说明',
          content: [
            '代金券',
            '优惠券',
            'Vmall积分',
            '优购码',
            '花瓣',
            '优享购',
            '会员增值券'
          ]
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1541492615647.png',
          title: '售后服务',
          content: [
            '保修政策',
            '退换货政策',
            '申请退换货',
            '手机寄修服务',
            '门店维修',
            '维修备件价格查询',
            '发票类',
            '退款方式和周期',
            '评价规则'
          ]
        }
      ],
      productarealist: [
        {
          img:
            'https://res.vmallres.com/pimages//pages/helpCategory/ErFexHMHEFITWu3bF4Sw.png',
          title: '华为手机',
          more: '更多',
          a1: 'HUAWEI P30 Pro',
          a2: 'HUAWEI Mate 20 Pro',
          a3: 'HUAWEI Mate10',
          a4: 'HUAWEI nova 2s',
          a5: '华为畅享7S',
          a6: 'HUAWEI P10'
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1540970726609.jpg',
          title: '荣耀手机',
          more: '更多',
          a1: '荣耀20 Pro',
          a2: '荣耀9X PRO',
          a3: '荣耀9青春版',
          a4: '荣耀V10',
          a5: '荣耀v9 play'
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1540970735775.jpg',
          title: '笔记本 平板',
          more: '更多',
          a1: 'HUAWEI Matebook 14',
          a2: 'HUAWEI MateBook 13',
          a3: 'HUAWEI MateBook D',
          a4: 'HUAWEI MateBook X',
          a5: '华为平板M6'
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1540970745899.jpg',
          title: '智能穿戴',
          more: '更多',
          a1: '华为手环B5',
          a2: '华为运动手环',
          a3: 'HUAWEI WATCH2',
          a4: '荣耀手环3'
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1540970756890.jpg',
          title: '智能家居',
          more: '更多',
          a1: '荣耀智慧屏',
          a2: '华为5G CPE Pro',
          a3: '华为智能体脂秤',
          a4: '华为AI音箱'
        },
        {
          img:
            'https://res.vmallres.com/pimages//promotion/privilegeChannel/product/1540977969674.jpg',
          title: '配件产品',
          more: '更多',
          a1: 'HUAWEI FreeBuds 2',
          a2: '荣耀FlyPods Pro'
        }
      ],
      customerlist: {
        span: ['7x24小时在线聊天'],
        a: ['立即咨询'],
        p: ['专业客服在线对话，为您解决遇到的问题']
      },
      phonelist: {
        span: ['7x24小时客服热线   '],
        number: ['950805'],
        p: ['专业客服语音通话，为您解决遇到的问题']
      },
      suggestionlist: {
        span: ['意见反馈'],
        a: ['立即反馈'],
        p: ['您的意见帮助我们不断改进']
      }
    }
  },
  components: {
    Slider
  }
}
</script>
<style scoped>
.hot-board {
  width: 100%;
  height: 450px;
}
.hot-board .ec-slider {
  width: 100%;
  height: 450px;
  background: url('https://res.vmallres.com/pimages//pages/picImages/oBrOlgGe1DpewylQ8DpD.jpg')
    50% 0px no-repeat;
  position: relative;
  z-index: 1;
}
.hot-board .ec-slider ul.icon {
  height: 10px;
  text-align: center;
  position: absolute;
  bottom: 30px;
  left: 50%;
  width: 300px;
  margin-left: -150px;
}
.hot-board .ec-slider ul.icon > li {
  border-radius: 50%;
  border: 1px solid #fff;
  display: inline-block;
  *display: inline;
  *zoom: 1;
  height: 10px;
  line-height: 10px;
  text-align: center;
  color: #fff;
  margin-left: 10px;
  width: 10px;
  /* background-color: transparent; */
  cursor: default;
}
.hot-board .ec-slider ul.icon > li:hover {
  background-color: #fff;
}

.help-serch-entrance {
  background: #f8f8f8;
  padding: 32px 0;
}
.help-serch-entrance p {
  width: 800px;
  margin: 0 auto;
}
.help-serch-entrance p input {
  width: 662px;
  border: 0;
  height: 60px;
  border-right: 0;
  float: left;
  text-indent: 20px;
  font-size: 20px;
}
.help-serch-entrance p a {
  width: 137px;
  height: 60px;
  line-height: 60px;
  background: linear-gradient(90deg, #e43e2d 0, #ca141d 100%);
  border-radius: 0 1px 1px 0;
  float: left;
  font-size: 22px;
  color: #fff;
  text-align: center;
}
.help-menu .h {
  font-size: 26px;
  line-height: 36px;
  padding: 32px 0 16px 0;
}
.help-menu .help-menu-list {
  width: 1290px;
}
.help-menu .help-menu-list li {
  float: left;
  width: 168px;
  height: 168px;
  margin-right: 90px;
  margin-bottom: 32px;
  border-radius: 10px;
  background: #fff;
  cursor: pointer;
}
.help-menu .help-menu-list li:hover {
  box-shadow: 0 8px 16px 7px #f2f2f2;
}
.help-menu .help-menu-list li a {
  text-decoration: none;
  text-align: center;
}
.help-menu .help-menu-list li a img {
  display: block;
  margin: 24px auto;
  width: 72px;
  height: 72px;
}
.help-menu .help-menu-list li a span {
  display: block;
  font-size: 20px;
  line-height: 26px;
}
.help-banner-small a {
  display: block;
}
.help-banner-small a img {
  width: 1200px;
  vertical-align: top;
}
.helpclass-area {
  margin-top: 30px;
}
.helpclass-area ul {
  width: 1222px;
}
.helpclass-area li {
  float: left;
  width: 588px;
  min-height: 134px;
  margin-bottom: 20px;
  background: #f9f9f9;
  border: 1px solid #f3f3f3;
  margin-right: 20px;
  position: relative;
  border-radius: 10px;
}
.helpclass-area li img {
  width: 50px;
  height: 50px;
  position: absolute;
  top: 42px;
  left: 30px;
}
.helpclass-area li .helpclass-info {
  width: 410px;
  display: table-cell;
  vertical-align: middle;
  height: 134px;
  padding-left: 35px;
  position: relative;
  left: 110px;
}
.helpclass-area li .helpclass-info:before {
  content: '';
  width: 1px;
  height: 70px;
  background: #f3f3f3;
  position: absolute;
  top: 32px;
  left: 0;
}
.helpclass-area li .helpclass-info .helpclass-title {
  font-size: 16px;
  color: #cea775;
  margin-bottom: 6px;
  font-weight: bold;
}
.helpclass-area li .helpclass-info p a {
  font-size: 14px;
  color: #9f9f9f;
  float: left;
  margin-right: 10px;
  text-decoration: none;
  margin-bottom: 4px;
}
.helpclass-area li .helpclass-info p a:hover {
  color: #ca141d;
}
.help-container {
  background: #f0f0f0;
}
.help-title {
  font-size: 26px;
  color: #000;
  text-align: left;
  padding: 32px 0 16px;
  line-height: 32px;
}
.help-product {
  background: #fff;
  padding: 20px 20px 0 20px;
  border-radius: 10px;
}
.help-product .product-banner a {
  display: block;
}
.help-product .product-banner img {
  width: 1160px;
  vertical-align: top;
  float: none;
}
.product-area .product-area-list {
  width: 1230px;
}
.product-area .product-area-list li {
  float: left;
  width: 190px;
  margin-left: 4px;
}
.product-area .product-area-list li:first-child {
  margin-left: 0;
}
.product-area .product-area-list .product-area-detail {
  padding-top: 39px;
  position: relative;
}
.product-area .product-area-list .product-area-detail img {
  width: 130px;
  height: 130px;
  margin: 0 auto;
  display: block;
}
.product-area .product-area-list .product-area-title {
  color: #000;
  font-size: 20px;
  text-align: center;
  display: block;
  margin-top: 20px;
  margin-bottom: 43px;
}
.product-area .product-area-list li:hover .product-area-info {
  display: block;
}

.product-area .product-area-list li:hover .product-area-info {
  display: block;
}
.product-area .product-area-list .product-area-info {
  display: none;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 5;
  width: 190px;
  height: 262px;
}
.product-area .product-area-list .product-area-info:after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 190px;
  height: 262px;
  background: #000;
  opacity: 0.8;
  filter: alpha(opacity=80);
}
.product-area .product-area-list dl {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 10;
  padding-top: 15px;
  color: #fff;
  font-size: 16px;
}
.product-area .product-area-list dl dt {
  padding: 0 15px 8px 15px;
  position: relative;
  width: 160px;
}
.product-area .product-area-list .product-area-detail a {
  color: #fff;
}
.product-area .product-area-list dl dt a {
  position: absolute;
  top: 0;
  right: 15px;
}
.product-area .product-area-list dl dd {
  font-size: 16px;
}
.product-area .product-area-list dl dd:hover {
  background: #4a4a4a;
}
.product-area .product-area-list dl dd a {
  display: block;
  margin-left: 15px;
  line-height: 36px;
  width: 160px;
  overflow: hidden;
  white-space: nowrap;
}
.help-title {
  font-size: 26px;
  color: #000;
  text-align: left;
  padding: 32px 0 16px;
  line-height: 32px;
}
.help-contact {
  background: #fff;
  border-radius: 10px;
}
.help-contact .contact-btn {
  float: left;
  margin-top: 50px;
  margin-left: 60px;
}
.help-contact .contact-btn li {
  padding-left: 82px;
  position: relative;
  min-height: 62px;
  padding-top: 4px;
  margin-bottom: 42px;
}
.help-contact .contact-btn li:before {
  content: '';
  width: 62px;
  height: 62px;
  display: block;
  background: url('https://res8.vmallres.com/20200630/images/echannel/icon/icon-help.png')
    no-repeat;
  position: absolute;
  top: 2px;
  left: 0;
}
.help-contact .contact-btn li.contact-customer:before {
  background-position: 0 0;
}
.help-contact .contact-btn li.contact-phone:before {
  background-position: 0 -62px;
}
.help-contact .contact-btn li.contact-suggestion:before {
  background-position: 0 -124px;
}
.help-contact .contact-btn li .contact-title {
  font-size: 0;
  color: #000;
  margin-bottom: 8px;
}
.help-contact .contact-btn li .contact-title span {
  font-size: 18px;
}
.help-contact .contact-btn li a {
  width: 110px;
  height: 26px;
  line-height: 26px;
  background: #ddb076;
  font-size: 16px;
  text-align: center;
  display: inline-block;
  color: #fff;
  border-radius: 2px;
  margin-left: 28px;
}
.help-contact .contact-btn li p {
  color: #acacac;
  font-size: 16px;
}
.help-contact .contact-code {
  float: right;
  width: 672px;
  height: 280px;
  border-left: 1px solid #eaeaea;
  margin: 52px 0;
}
.help-contact .contact-code ul {
  margin-left: 30px;
  height: 220px;
  *zoom: 1;
}
.help-contact .contact-code ul:before,
.help-contact .contact-code ul:after {
  content: '';
  display: table;
}
.help-contact .contact-code li {
  margin-left: 52px;
  float: left;
}
.help-contact .contact-code li:before {
  content: '';
  width: 40px;
  height: 40px;
  display: block;
  margin: 0 auto;
  margin-bottom: 10px;
  background: url('https://res8.vmallres.com/20200630/images/echannel/icon/icon-help.png')
    no-repeat;
}
.help-contact .contact-code li.contact-wechat:before {
  background-position: -72px 0;
}
.help-contact .contact-code li.contact-weibo:before {
  background-position: -72px -41px;
}
.help-contact .contact-code li.contact-app:before {
  background-position: -72px -82px;
}
.help-contact .contact-code li img {
  width: 140px;
  height: 140px;
  vertical-align: top;
}
.help-contact .contact-code li span {
  display: block;
  font-size: 16px;
  text-align: center;
  margin-top: 10px;
}
.help-contact .contact-code .tips {
  font-size: 16px;
  color: #acacac;
  text-align: center;
  margin-top: 30px;
}
.help-title {
  font-size: 26px;
  color: #000;
  text-align: left;
  padding: 32px 0 16px;
  line-height: 32px;
}
.help-banner {
  text-align: center;
}
.help-banner a {
  display: block;
}
.help-banner img {
  vertical-align: top;
  width: 1200px;
  margin-bottom: 32px;
  border-radius: 10px;
}
</style>
