<template>
  <el-carousel :interval="5000" arrow="never" style="height:450px">
    <el-carousel-item v-for="(item, index) in imglist" :key="index">
      <img :src="item.src" style="height:450px" />
    </el-carousel-item>
  </el-carousel>
</template>

<script>
export default {
  name: 'swiper',
  data() {
    return {
      imglist: [
        {
          src:
            'https://res.vmallres.com/pimages//pages/picImages/oBrOlgGe1DpewylQ8DpD.jpg'
        },
        {
          src:
            'https://res.vmallres.com/pimages//pages/picImages/JLFekhFFq3GHaMqV7CQa.png'
        },
        {
          src:
            'https://res.vmallres.com/pimages//sale/2019-04/3LP39i3UdxwXc1ioiXFS.jpg'
        },
        {
          src:
            'https://res.vmallres.com/pimages//sale/2018-11/20181113114642803.png'
        }
      ]
    }
  }
}
</script>
<style scoped>
.el-carousel__item img {
  color: #475669;
  font-size: 18px;
  opacity: 1;
  line-height: 300px;
  width: 1200px;
  margin: 0 auto;
}
.el-carousel__item:nth-child(2n) {
  background-color: white;
}
.el-carousel__item:nth-child(2n + 1) {
  background-color: white;
}
li button.el-carousel__button {
  display: block;
  opacity: 0.48;
  width: 12px;
  height: 12px;
  border-radius: 12px;
  border: 1px solid #fff;
  outline: 0;
  padding: 0;
  margin-left: 1px;
  cursor: pointer;
  transition: 0.3s;
  background-color: transparent;
}
li.is-active button.el-carousel__button {
  background-color: #fff;
}
.el-carousel__indicators--horizontal {
  bottom: 16px !important;
  left: 50%;
  transform: translateX(-50%);
}
.el-carousel__container {
  width: 100%;
  height: 450px !important;
}
.el-carousel__item {
  width: 100%;
  height: 450px;
}
.el-carousel__item img {
  width: 100%;
  height: 450px;
  object-fit: none;
}
</style>
