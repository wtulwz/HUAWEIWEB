import Vue from 'vue'
import VueRouter from 'vue-router'
import huawei from '../views/huawei.vue'
import mi from '../views/mi.vue'
import honor30 from '../views/honor30.vue'
import business from '../views/business.vue'
import p40 from '../views/p40.vue'
import dianchi from '../views/dianchi.vue'
import serve from '../views/serve.vue'
import honor from '../views/honor.vue'
Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'huawei',
    component: huawei,
  },
  {
    path: '/mi',
    name: 'mi',
    component: mi,
  },
  {
    path: '/honor30',
    name: 'honor30',
    component: honor30,
  },
  {
    path: '/business',
    name: 'business',
    component: business,
  },
  ,
  {
    path: '/p40',
    name: 'p40',
    component: p40,
  },
  {
    path: '/dianchi',
    name: 'dianchi',
    component: dianchi,
  },
  {
    path: '/serve',
    name: 'serve',
    component: serve,
  },
  {
    path: '/honor',
    name: 'honor',
    component: honor,
  },
]

const router = new VueRouter({
  mode: 'hash',
  base: process.env.BASE_URL,
  routes,
})

export default router
