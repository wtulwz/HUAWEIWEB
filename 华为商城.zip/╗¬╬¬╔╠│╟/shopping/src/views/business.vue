<template>
  <div>
    <!--right_nav-->
    <right_nav></right_nav>
    <!--topheader-->
    <topheader> </topheader><br /><br />
    <!-- slider-->
    <slider></slider>
    <slider2></slider2><br /><br /><br /><br /><br />
    <!--Product-->
    <Product></Product>
    <!--Footer -->
    <Footer></Footer>
  </div>
</template>
<script>
import topheader from '@/components/business/topheader.vue'
import slider from '@/components/business/slider.vue'
import slider2 from '@/components/business/slider2.vue'
import right_nav from '@/components/business/right_nav.vue'
import Footer from '@/components/business/Footer.vue'
import Product from '@/components/business/Product.vue'
export default {
  components: {
    topheader,
    slider,
    slider2,
    right_nav,
    Footer,
    Product
  },
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped></style>
