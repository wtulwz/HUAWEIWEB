<template>
  <div>
    <Header></Header>
    <bodys></bodys>
    <Footer></Footer>
  </div>
</template>
<script>
import Header from '@/components/dianchi/Header.vue'
import bodys from '@/components/dianchi/bodys.vue'
import Footer from '@/components/dianchi/Footer.vue'
export default {
  components: {
    Header,
    bodys,
    Footer
  },
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped></style>
