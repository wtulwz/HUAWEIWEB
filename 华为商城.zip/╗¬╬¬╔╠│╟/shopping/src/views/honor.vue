<template>
  <div class="big">
    <Header></Header>
    <div class="fixedNav">
      <div class="layout">
        <ul>
          <li>
            <a href="#5g"> </a>
          </li>
          <li>
            <a href="#phone"> </a>
          </li>
          <li>
            <a href="#baokuan"></a>
          </li>
          <li>
            <a href="#chaoliu"></a>
          </li>
        </ul>
      </div>
    </div>
    <Mainbanner></Mainbanner>
    <Footer></Footer>
  </div>
</template>
<script>
import Header from '@/components/honor/Header.vue'
import Mainbanner from '@/components/honor/Mainbanner.vue'
import Footer from '@/components/honor/Footer.vue'

export default {
  name: 'honorIndex',
  components: {
    Header,
    Mainbanner,
    Footer
  },
  data() {
    return {
      fixedUList: [
        {
          title: ' ',
          url: '5g'
        },
        {
          title: ' ',
          url: '5g'
        },
        {
          title: ' ',
          url: '5g'
        },
        {
          title: ' ',
          url: '5g'
        }
      ]
    }
  }
}
</script>
<style scoped>
.big {
  width: 100%;
  height: 100%;
  background-color: #d3e6ff;
}
li {
  list-style-type: none;
}
a {
  text-decoration: none;
  color: #afafaf;
}
.layout {
  width: 1200px;
  margin: 0 auto;
}
.text-left {
  width: 123px;
  overflow: hidden;
  float: left;
}
.text-right {
  width: 137px;
  float: right;
  text-align: left !important;
}
.clearfix::after {
  content: '';
  display: block;
  height: 0;
  visibility: hidden;
  clear: both;
}
.fixedNav {
  height: 80px;
  position: sticky;
  top: -1px;
  background-color: transparent;
  background: url(https://res2.vmallres.com/shopdc/pic/1aa10973-abd3-4565-8624-6d411041986a.jpg)
    center no-repeat;
  z-index: 3;
}
.fixedNav .layout {
  height: 80px;
}
.fixedNav .layout ul {
  height: 80px;
  display: flex;
  justify-content: space-around;
  align-items: center;
}
.fixedNav .layout ul li {
  height: 80px;
  width: 100%;
  line-height: 72px;
  text-align: center;
  position: relative;
}
.fixedNav .layout ul li a {
  height: 80px;
  color: #ffffff;
  display: block;
  width: 100%;
  font-size: 20px;
}
</style>
