<template>
  <div style="background:rgb(234, 234, 248);">
    <top></top>
    <slider></slider>
    <qijian></qijian>
    <news></news>
    <hot></hot><br /><br /><br /><br />
    <choujiang></choujiang>
    <Footer></Footer>
  </div>
</template>
<script>
import top from '@/components/honor30/top.vue'
import slider from '@/components/honor30/slider.vue'
import qijian from '@/components/honor30/qijian.vue'
import news from '@/components/honor30/news.vue'
import hot from '@/components/honor30/hot.vue'
import choujiang from '@/components/honor30/choujiang.vue'
import Footer from '@/components/honor30/Footer.vue'

export default {
  components: {
    top,
    slider,
    qijian,
    news,
    hot,
    choujiang,
    Footer
  },
  data() {
    return {}
  },
  methods: {}
}
</script>
<style scoped></style>
