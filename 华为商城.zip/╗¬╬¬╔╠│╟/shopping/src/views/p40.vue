<template>
  <div class="J_row chearfix">
    <div class="J_col col-side-full clearfix">
      <Header></Header>
      <Slideshow></Slideshow>
      <Banner></Banner>
      <Tail></Tail>
    </div>
  </div>
</template>

<script>
// @ is an alias to /src
import Header from '@/components/p40/Header.vue'
import Slideshow from '@/components/p40/Slideshow.vue'
import Banner from '@/components/p40/Banner.vue'
import Tail from '@/components/p40/Tail.vue'
export default {
  name: 'Home',
  components: {
    Header,
    Slideshow,
    Banner,
    Tail
  }
}
</script>
