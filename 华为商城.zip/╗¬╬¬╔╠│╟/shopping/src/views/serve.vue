<template>
  <div>
    <ServeHeader></ServeHeader>
    <ServeMain></ServeMain>
    <ServeFooter></ServeFooter>
  </div>
</template>
<script>
import ServeHeader from '@/components/serve/ServeHeader.vue'
import ServeMain from '@/components/serve/ServeMain.vue'
import ServeFooter from '@/components/serve/ServeFooter.vue'
export default {
  name: 'Index',
  components: {
    ServeHeader,
    ServeMain,
    ServeFooter
  }
}
</script>
<style scoped>
* {
  margin: 0;
  padding: 0;
}
html,
body {
  width: 100%;
  height: 100%;
}
body,
button,
input {
  font: 12px/1.5 'Helvetica Neue', Helvetica, Arial, 'Microsoft Yahei',
    'Hiragino Sans GB', 'Heiti SC', 'WenQuanYi Micro Hei', sans-serif;
}
input {
  font-size: 100%;
}
#app {
  width: 100%;
  height: 100%;
}
.layout {
  width: 1200px;
  height: 100%;
  margin: 0 auto;
}
.layout:before,
.layout:after {
  content: '';
  display: table;
}
.clearfix {
  *zoom: 1;
}
.clearfix:before,
.clearfix:after {
  content: ' ';
  display: table;
}
.clearfix:after {
  clear: both;
}
li {
  list-style-type: none;
}
a {
  text-decoration: none;
  color: #3a3a3a;
  cursor: pointer;
}
.fl {
  float: left;
}
input {
  border: none;
  outline: none;
}
</style>
